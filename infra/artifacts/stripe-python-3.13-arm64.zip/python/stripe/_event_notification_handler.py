"""
We use a combination of generics and inheritance to construct 4 handler classes with perfect type information while reusing as much code as we can.
Each handler has the methods/signatures that will actually work:

|       | verified                            | unverified                                             |
| ----- | ----------------------------------- | ------------------------------------------------------ |
| sync  | StripeEventNotificationHandler      | StripeEventNotificationHandlerWithoutVerification      |
| async | AsyncStripeEventNotificationHandler | AsyncStripeEventNotificationHandlerWithoutVerification |

A pair of generic variables gives us the following class hierarchy (names edited for brevity):

- _BaseHandler(Generic[CallbackReturn, PreHandleReturn])
    - _SyncHandler(_BaseHandler[None, bool])
        - StripeHandler(_SyncHandler)
        - StripeHandlerWithoutVerification(_SyncHandler)
    - _AsyncHandler(_BaseHandler[None, bool])
        - AsyncStripeHandler(_AsyncHandler)
        - AsyncStripeHandlerWithoutVerification(_AsyncHandler)

Each defines `handle` and `register` methods corresponding to the types it expects
"""

from dataclasses import dataclass
from typing_extensions import TYPE_CHECKING, Awaitable

from typing import (
    Callable,
    Generic,
    List,
    Optional,
    TypeVar,
)

# Import at runtime for isinstance check and type annotations
from stripe.v2.core._event import EventNotification, UnknownEventNotification
from stripe._webhook import WebhookPayload

if TYPE_CHECKING:
    from stripe._stripe_client import StripeClient

    # event-notification-types: The beginning of the section generated from our OpenAPI spec
    from stripe.events._v1_account_application_authorized_event import (
        V1AccountApplicationAuthorizedEventNotification,
    )
    from stripe.events._v1_account_application_deauthorized_event import (
        V1AccountApplicationDeauthorizedEventNotification,
    )
    from stripe.events._v1_account_external_account_created_event import (
        V1AccountExternalAccountCreatedEventNotification,
    )
    from stripe.events._v1_account_external_account_deleted_event import (
        V1AccountExternalAccountDeletedEventNotification,
    )
    from stripe.events._v1_account_external_account_updated_event import (
        V1AccountExternalAccountUpdatedEventNotification,
    )
    from stripe.events._v1_account_updated_event import (
        V1AccountUpdatedEventNotification,
    )
    from stripe.events._v1_application_fee_created_event import (
        V1ApplicationFeeCreatedEventNotification,
    )
    from stripe.events._v1_application_fee_refunded_event import (
        V1ApplicationFeeRefundedEventNotification,
    )
    from stripe.events._v1_application_fee_refund_updated_event import (
        V1ApplicationFeeRefundUpdatedEventNotification,
    )
    from stripe.events._v1_balance_available_event import (
        V1BalanceAvailableEventNotification,
    )
    from stripe.events._v1_balance_settings_updated_event import (
        V1BalanceSettingsUpdatedEventNotification,
    )
    from stripe.events._v1_billing_alert_triggered_event import (
        V1BillingAlertTriggeredEventNotification,
    )
    from stripe.events._v1_billing_credit_balance_transaction_created_event import (
        V1BillingCreditBalanceTransactionCreatedEventNotification,
    )
    from stripe.events._v1_billing_credit_grant_created_event import (
        V1BillingCreditGrantCreatedEventNotification,
    )
    from stripe.events._v1_billing_credit_grant_updated_event import (
        V1BillingCreditGrantUpdatedEventNotification,
    )
    from stripe.events._v1_billing_meter_created_event import (
        V1BillingMeterCreatedEventNotification,
    )
    from stripe.events._v1_billing_meter_deactivated_event import (
        V1BillingMeterDeactivatedEventNotification,
    )
    from stripe.events._v1_billing_meter_error_report_triggered_event import (
        V1BillingMeterErrorReportTriggeredEventNotification,
    )
    from stripe.events._v1_billing_meter_no_meter_found_event import (
        V1BillingMeterNoMeterFoundEventNotification,
    )
    from stripe.events._v1_billing_meter_reactivated_event import (
        V1BillingMeterReactivatedEventNotification,
    )
    from stripe.events._v1_billing_meter_updated_event import (
        V1BillingMeterUpdatedEventNotification,
    )
    from stripe.events._v1_billing_portal_configuration_created_event import (
        V1BillingPortalConfigurationCreatedEventNotification,
    )
    from stripe.events._v1_billing_portal_configuration_updated_event import (
        V1BillingPortalConfigurationUpdatedEventNotification,
    )
    from stripe.events._v1_billing_portal_session_created_event import (
        V1BillingPortalSessionCreatedEventNotification,
    )
    from stripe.events._v1_capability_updated_event import (
        V1CapabilityUpdatedEventNotification,
    )
    from stripe.events._v1_cash_balance_funds_available_event import (
        V1CashBalanceFundsAvailableEventNotification,
    )
    from stripe.events._v1_charge_captured_event import (
        V1ChargeCapturedEventNotification,
    )
    from stripe.events._v1_charge_dispute_closed_event import (
        V1ChargeDisputeClosedEventNotification,
    )
    from stripe.events._v1_charge_dispute_created_event import (
        V1ChargeDisputeCreatedEventNotification,
    )
    from stripe.events._v1_charge_dispute_funds_reinstated_event import (
        V1ChargeDisputeFundsReinstatedEventNotification,
    )
    from stripe.events._v1_charge_dispute_funds_withdrawn_event import (
        V1ChargeDisputeFundsWithdrawnEventNotification,
    )
    from stripe.events._v1_charge_dispute_updated_event import (
        V1ChargeDisputeUpdatedEventNotification,
    )
    from stripe.events._v1_charge_expired_event import (
        V1ChargeExpiredEventNotification,
    )
    from stripe.events._v1_charge_failed_event import (
        V1ChargeFailedEventNotification,
    )
    from stripe.events._v1_charge_pending_event import (
        V1ChargePendingEventNotification,
    )
    from stripe.events._v1_charge_refunded_event import (
        V1ChargeRefundedEventNotification,
    )
    from stripe.events._v1_charge_refund_updated_event import (
        V1ChargeRefundUpdatedEventNotification,
    )
    from stripe.events._v1_charge_succeeded_event import (
        V1ChargeSucceededEventNotification,
    )
    from stripe.events._v1_charge_updated_event import (
        V1ChargeUpdatedEventNotification,
    )
    from stripe.events._v1_checkout_session_async_payment_failed_event import (
        V1CheckoutSessionAsyncPaymentFailedEventNotification,
    )
    from stripe.events._v1_checkout_session_async_payment_succeeded_event import (
        V1CheckoutSessionAsyncPaymentSucceededEventNotification,
    )
    from stripe.events._v1_checkout_session_completed_event import (
        V1CheckoutSessionCompletedEventNotification,
    )
    from stripe.events._v1_checkout_session_expired_event import (
        V1CheckoutSessionExpiredEventNotification,
    )
    from stripe.events._v1_climate_order_canceled_event import (
        V1ClimateOrderCanceledEventNotification,
    )
    from stripe.events._v1_climate_order_created_event import (
        V1ClimateOrderCreatedEventNotification,
    )
    from stripe.events._v1_climate_order_delayed_event import (
        V1ClimateOrderDelayedEventNotification,
    )
    from stripe.events._v1_climate_order_delivered_event import (
        V1ClimateOrderDeliveredEventNotification,
    )
    from stripe.events._v1_climate_order_product_substituted_event import (
        V1ClimateOrderProductSubstitutedEventNotification,
    )
    from stripe.events._v1_climate_product_created_event import (
        V1ClimateProductCreatedEventNotification,
    )
    from stripe.events._v1_climate_product_pricing_updated_event import (
        V1ClimateProductPricingUpdatedEventNotification,
    )
    from stripe.events._v1_coupon_created_event import (
        V1CouponCreatedEventNotification,
    )
    from stripe.events._v1_coupon_deleted_event import (
        V1CouponDeletedEventNotification,
    )
    from stripe.events._v1_coupon_updated_event import (
        V1CouponUpdatedEventNotification,
    )
    from stripe.events._v1_credit_note_created_event import (
        V1CreditNoteCreatedEventNotification,
    )
    from stripe.events._v1_credit_note_updated_event import (
        V1CreditNoteUpdatedEventNotification,
    )
    from stripe.events._v1_credit_note_voided_event import (
        V1CreditNoteVoidedEventNotification,
    )
    from stripe.events._v1_customer_cash_balance_transaction_created_event import (
        V1CustomerCashBalanceTransactionCreatedEventNotification,
    )
    from stripe.events._v1_customer_created_event import (
        V1CustomerCreatedEventNotification,
    )
    from stripe.events._v1_customer_deleted_event import (
        V1CustomerDeletedEventNotification,
    )
    from stripe.events._v1_customer_discount_created_event import (
        V1CustomerDiscountCreatedEventNotification,
    )
    from stripe.events._v1_customer_discount_deleted_event import (
        V1CustomerDiscountDeletedEventNotification,
    )
    from stripe.events._v1_customer_discount_source_changed_event import (
        V1CustomerDiscountSourceChangedEventNotification,
    )
    from stripe.events._v1_customer_discount_updated_event import (
        V1CustomerDiscountUpdatedEventNotification,
    )
    from stripe.events._v1_customer_subscription_active_event import (
        V1CustomerSubscriptionActiveEventNotification,
    )
    from stripe.events._v1_customer_subscription_cancel_at_changed_event import (
        V1CustomerSubscriptionCancelAtChangedEventNotification,
    )
    from stripe.events._v1_customer_subscription_created_event import (
        V1CustomerSubscriptionCreatedEventNotification,
    )
    from stripe.events._v1_customer_subscription_default_payment_method_changed_event import (
        V1CustomerSubscriptionDefaultPaymentMethodChangedEventNotification,
    )
    from stripe.events._v1_customer_subscription_deleted_event import (
        V1CustomerSubscriptionDeletedEventNotification,
    )
    from stripe.events._v1_customer_subscription_incomplete_event import (
        V1CustomerSubscriptionIncompleteEventNotification,
    )
    from stripe.events._v1_customer_subscription_incomplete_expired_event import (
        V1CustomerSubscriptionIncompleteExpiredEventNotification,
    )
    from stripe.events._v1_customer_subscription_item_added_event import (
        V1CustomerSubscriptionItemAddedEventNotification,
    )
    from stripe.events._v1_customer_subscription_item_price_changed_event import (
        V1CustomerSubscriptionItemPriceChangedEventNotification,
    )
    from stripe.events._v1_customer_subscription_item_quantity_changed_event import (
        V1CustomerSubscriptionItemQuantityChangedEventNotification,
    )
    from stripe.events._v1_customer_subscription_item_removed_event import (
        V1CustomerSubscriptionItemRemovedEventNotification,
    )
    from stripe.events._v1_customer_subscription_item_tax_rates_changed_event import (
        V1CustomerSubscriptionItemTaxRatesChangedEventNotification,
    )
    from stripe.events._v1_customer_subscription_past_due_event import (
        V1CustomerSubscriptionPastDueEventNotification,
    )
    from stripe.events._v1_customer_subscription_paused_event import (
        V1CustomerSubscriptionPausedEventNotification,
    )
    from stripe.events._v1_customer_subscription_pending_update_applied_event import (
        V1CustomerSubscriptionPendingUpdateAppliedEventNotification,
    )
    from stripe.events._v1_customer_subscription_pending_update_expired_event import (
        V1CustomerSubscriptionPendingUpdateExpiredEventNotification,
    )
    from stripe.events._v1_customer_subscription_resumed_event import (
        V1CustomerSubscriptionResumedEventNotification,
    )
    from stripe.events._v1_customer_subscription_trialing_event import (
        V1CustomerSubscriptionTrialingEventNotification,
    )
    from stripe.events._v1_customer_subscription_trial_will_end_event import (
        V1CustomerSubscriptionTrialWillEndEventNotification,
    )
    from stripe.events._v1_customer_subscription_unpaid_event import (
        V1CustomerSubscriptionUnpaidEventNotification,
    )
    from stripe.events._v1_customer_subscription_updated_event import (
        V1CustomerSubscriptionUpdatedEventNotification,
    )
    from stripe.events._v1_customer_tax_id_created_event import (
        V1CustomerTaxIdCreatedEventNotification,
    )
    from stripe.events._v1_customer_tax_id_deleted_event import (
        V1CustomerTaxIdDeletedEventNotification,
    )
    from stripe.events._v1_customer_tax_id_updated_event import (
        V1CustomerTaxIdUpdatedEventNotification,
    )
    from stripe.events._v1_customer_updated_event import (
        V1CustomerUpdatedEventNotification,
    )
    from stripe.events._v1_entitlements_active_entitlement_summary_entitlement_added_event import (
        V1EntitlementsActiveEntitlementSummaryEntitlementAddedEventNotification,
    )
    from stripe.events._v1_entitlements_active_entitlement_summary_entitlement_removed_event import (
        V1EntitlementsActiveEntitlementSummaryEntitlementRemovedEventNotification,
    )
    from stripe.events._v1_entitlements_active_entitlement_summary_updated_event import (
        V1EntitlementsActiveEntitlementSummaryUpdatedEventNotification,
    )
    from stripe.events._v1_file_created_event import (
        V1FileCreatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_account_numbers_updated_event import (
        V1FinancialConnectionsAccountAccountNumbersUpdatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_balance_refresh_failed_event import (
        V1FinancialConnectionsAccountBalanceRefreshFailedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_balance_refresh_succeeded_event import (
        V1FinancialConnectionsAccountBalanceRefreshSucceededEventNotification,
    )
    from stripe.events._v1_financial_connections_account_created_event import (
        V1FinancialConnectionsAccountCreatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_deactivated_event import (
        V1FinancialConnectionsAccountDeactivatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_disconnected_event import (
        V1FinancialConnectionsAccountDisconnectedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_expected_deactivation_date_updated_event import (
        V1FinancialConnectionsAccountExpectedDeactivationDateUpdatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_inferred_balances_refresh_failed_event import (
        V1FinancialConnectionsAccountInferredBalancesRefreshFailedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_inferred_balances_refresh_succeeded_event import (
        V1FinancialConnectionsAccountInferredBalancesRefreshSucceededEventNotification,
    )
    from stripe.events._v1_financial_connections_account_ownership_refresh_failed_event import (
        V1FinancialConnectionsAccountOwnershipRefreshFailedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_ownership_refresh_succeeded_event import (
        V1FinancialConnectionsAccountOwnershipRefreshSucceededEventNotification,
    )
    from stripe.events._v1_financial_connections_account_reactivated_event import (
        V1FinancialConnectionsAccountReactivatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_refreshed_balance_event import (
        V1FinancialConnectionsAccountRefreshedBalanceEventNotification,
    )
    from stripe.events._v1_financial_connections_account_refreshed_ownership_event import (
        V1FinancialConnectionsAccountRefreshedOwnershipEventNotification,
    )
    from stripe.events._v1_financial_connections_account_refreshed_transactions_event import (
        V1FinancialConnectionsAccountRefreshedTransactionsEventNotification,
    )
    from stripe.events._v1_financial_connections_account_risk_intelligence_refresh_failed_event import (
        V1FinancialConnectionsAccountRiskIntelligenceRefreshFailedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_risk_intelligence_refresh_succeeded_event import (
        V1FinancialConnectionsAccountRiskIntelligenceRefreshSucceededEventNotification,
    )
    from stripe.events._v1_financial_connections_account_supported_payment_method_types_updated_event import (
        V1FinancialConnectionsAccountSupportedPaymentMethodTypesUpdatedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_transactions_refresh_failed_event import (
        V1FinancialConnectionsAccountTransactionsRefreshFailedEventNotification,
    )
    from stripe.events._v1_financial_connections_account_transactions_refresh_succeeded_event import (
        V1FinancialConnectionsAccountTransactionsRefreshSucceededEventNotification,
    )
    from stripe.events._v1_financial_connections_account_upcoming_account_number_expiry_event import (
        V1FinancialConnectionsAccountUpcomingAccountNumberExpiryEventNotification,
    )
    from stripe.events._v1_financial_connections_account_upcoming_deactivation_event import (
        V1FinancialConnectionsAccountUpcomingDeactivationEventNotification,
    )
    from stripe.events._v1_identity_verification_session_canceled_event import (
        V1IdentityVerificationSessionCanceledEventNotification,
    )
    from stripe.events._v1_identity_verification_session_created_event import (
        V1IdentityVerificationSessionCreatedEventNotification,
    )
    from stripe.events._v1_identity_verification_session_processing_event import (
        V1IdentityVerificationSessionProcessingEventNotification,
    )
    from stripe.events._v1_identity_verification_session_redacted_event import (
        V1IdentityVerificationSessionRedactedEventNotification,
    )
    from stripe.events._v1_identity_verification_session_requires_input_event import (
        V1IdentityVerificationSessionRequiresInputEventNotification,
    )
    from stripe.events._v1_identity_verification_session_verified_event import (
        V1IdentityVerificationSessionVerifiedEventNotification,
    )
    from stripe.events._v1_invoice_created_event import (
        V1InvoiceCreatedEventNotification,
    )
    from stripe.events._v1_invoice_deleted_event import (
        V1InvoiceDeletedEventNotification,
    )
    from stripe.events._v1_invoice_discount_added_event import (
        V1InvoiceDiscountAddedEventNotification,
    )
    from stripe.events._v1_invoice_discount_removed_event import (
        V1InvoiceDiscountRemovedEventNotification,
    )
    from stripe.events._v1_invoice_finalization_failed_event import (
        V1InvoiceFinalizationFailedEventNotification,
    )
    from stripe.events._v1_invoice_finalized_event import (
        V1InvoiceFinalizedEventNotification,
    )
    from stripe.events._v1_invoiceitem_amount_changed_event import (
        V1InvoiceitemAmountChangedEventNotification,
    )
    from stripe.events._v1_invoiceitem_created_event import (
        V1InvoiceitemCreatedEventNotification,
    )
    from stripe.events._v1_invoiceitem_deleted_event import (
        V1InvoiceitemDeletedEventNotification,
    )
    from stripe.events._v1_invoiceitem_discount_added_event import (
        V1InvoiceitemDiscountAddedEventNotification,
    )
    from stripe.events._v1_invoiceitem_discount_removed_event import (
        V1InvoiceitemDiscountRemovedEventNotification,
    )
    from stripe.events._v1_invoice_line_item_added_event import (
        V1InvoiceLineItemAddedEventNotification,
    )
    from stripe.events._v1_invoice_line_item_pricing_changed_event import (
        V1InvoiceLineItemPricingChangedEventNotification,
    )
    from stripe.events._v1_invoice_line_item_quantity_changed_event import (
        V1InvoiceLineItemQuantityChangedEventNotification,
    )
    from stripe.events._v1_invoice_line_item_removed_event import (
        V1InvoiceLineItemRemovedEventNotification,
    )
    from stripe.events._v1_invoice_marked_uncollectible_event import (
        V1InvoiceMarkedUncollectibleEventNotification,
    )
    from stripe.events._v1_invoice_overdue_event import (
        V1InvoiceOverdueEventNotification,
    )
    from stripe.events._v1_invoice_overpaid_event import (
        V1InvoiceOverpaidEventNotification,
    )
    from stripe.events._v1_invoice_paid_event import (
        V1InvoicePaidEventNotification,
    )
    from stripe.events._v1_invoice_payment_action_required_event import (
        V1InvoicePaymentActionRequiredEventNotification,
    )
    from stripe.events._v1_invoice_payment_attempt_required_event import (
        V1InvoicePaymentAttemptRequiredEventNotification,
    )
    from stripe.events._v1_invoice_payment_canceled_event import (
        V1InvoicePaymentCanceledEventNotification,
    )
    from stripe.events._v1_invoice_payment_failed_event import (
        V1InvoicePaymentFailedEventNotification,
    )
    from stripe.events._v1_invoice_payment_open_event import (
        V1InvoicePaymentOpenEventNotification,
    )
    from stripe.events._v1_invoice_payment_paid_event import (
        V1InvoicePaymentPaidEventNotification,
    )
    from stripe.events._v1_invoice_payment_succeeded_event import (
        V1InvoicePaymentSucceededEventNotification,
    )
    from stripe.events._v1_invoice_sent_event import (
        V1InvoiceSentEventNotification,
    )
    from stripe.events._v1_invoice_upcoming_event import (
        V1InvoiceUpcomingEventNotification,
    )
    from stripe.events._v1_invoice_updated_event import (
        V1InvoiceUpdatedEventNotification,
    )
    from stripe.events._v1_invoice_voided_event import (
        V1InvoiceVoidedEventNotification,
    )
    from stripe.events._v1_invoice_will_be_due_event import (
        V1InvoiceWillBeDueEventNotification,
    )
    from stripe.events._v1_issuing_authorization_created_event import (
        V1IssuingAuthorizationCreatedEventNotification,
    )
    from stripe.events._v1_issuing_authorization_request_event import (
        V1IssuingAuthorizationRequestEventNotification,
    )
    from stripe.events._v1_issuing_authorization_updated_event import (
        V1IssuingAuthorizationUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_card_created_event import (
        V1IssuingCardCreatedEventNotification,
    )
    from stripe.events._v1_issuing_cardholder_created_event import (
        V1IssuingCardholderCreatedEventNotification,
    )
    from stripe.events._v1_issuing_cardholder_updated_event import (
        V1IssuingCardholderUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_card_updated_event import (
        V1IssuingCardUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_dispute_closed_event import (
        V1IssuingDisputeClosedEventNotification,
    )
    from stripe.events._v1_issuing_dispute_created_event import (
        V1IssuingDisputeCreatedEventNotification,
    )
    from stripe.events._v1_issuing_dispute_funds_reinstated_event import (
        V1IssuingDisputeFundsReinstatedEventNotification,
    )
    from stripe.events._v1_issuing_dispute_funds_rescinded_event import (
        V1IssuingDisputeFundsRescindedEventNotification,
    )
    from stripe.events._v1_issuing_dispute_submitted_event import (
        V1IssuingDisputeSubmittedEventNotification,
    )
    from stripe.events._v1_issuing_dispute_updated_event import (
        V1IssuingDisputeUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_personalization_design_activated_event import (
        V1IssuingPersonalizationDesignActivatedEventNotification,
    )
    from stripe.events._v1_issuing_personalization_design_deactivated_event import (
        V1IssuingPersonalizationDesignDeactivatedEventNotification,
    )
    from stripe.events._v1_issuing_personalization_design_rejected_event import (
        V1IssuingPersonalizationDesignRejectedEventNotification,
    )
    from stripe.events._v1_issuing_personalization_design_updated_event import (
        V1IssuingPersonalizationDesignUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_token_created_event import (
        V1IssuingTokenCreatedEventNotification,
    )
    from stripe.events._v1_issuing_token_updated_event import (
        V1IssuingTokenUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_transaction_created_event import (
        V1IssuingTransactionCreatedEventNotification,
    )
    from stripe.events._v1_issuing_transaction_purchase_details_receipt_updated_event import (
        V1IssuingTransactionPurchaseDetailsReceiptUpdatedEventNotification,
    )
    from stripe.events._v1_issuing_transaction_updated_event import (
        V1IssuingTransactionUpdatedEventNotification,
    )
    from stripe.events._v1_mandate_updated_event import (
        V1MandateUpdatedEventNotification,
    )
    from stripe.events._v1_payment_intent_amount_capturable_updated_event import (
        V1PaymentIntentAmountCapturableUpdatedEventNotification,
    )
    from stripe.events._v1_payment_intent_canceled_event import (
        V1PaymentIntentCanceledEventNotification,
    )
    from stripe.events._v1_payment_intent_created_event import (
        V1PaymentIntentCreatedEventNotification,
    )
    from stripe.events._v1_payment_intent_partially_funded_event import (
        V1PaymentIntentPartiallyFundedEventNotification,
    )
    from stripe.events._v1_payment_intent_payment_failed_event import (
        V1PaymentIntentPaymentFailedEventNotification,
    )
    from stripe.events._v1_payment_intent_processing_event import (
        V1PaymentIntentProcessingEventNotification,
    )
    from stripe.events._v1_payment_intent_requires_action_event import (
        V1PaymentIntentRequiresActionEventNotification,
    )
    from stripe.events._v1_payment_intent_succeeded_event import (
        V1PaymentIntentSucceededEventNotification,
    )
    from stripe.events._v1_payment_link_created_event import (
        V1PaymentLinkCreatedEventNotification,
    )
    from stripe.events._v1_payment_link_updated_event import (
        V1PaymentLinkUpdatedEventNotification,
    )
    from stripe.events._v1_payment_method_attached_event import (
        V1PaymentMethodAttachedEventNotification,
    )
    from stripe.events._v1_payment_method_automatically_updated_event import (
        V1PaymentMethodAutomaticallyUpdatedEventNotification,
    )
    from stripe.events._v1_payment_method_detached_event import (
        V1PaymentMethodDetachedEventNotification,
    )
    from stripe.events._v1_payment_method_updated_event import (
        V1PaymentMethodUpdatedEventNotification,
    )
    from stripe.events._v1_payout_canceled_event import (
        V1PayoutCanceledEventNotification,
    )
    from stripe.events._v1_payout_created_event import (
        V1PayoutCreatedEventNotification,
    )
    from stripe.events._v1_payout_failed_event import (
        V1PayoutFailedEventNotification,
    )
    from stripe.events._v1_payout_paid_event import (
        V1PayoutPaidEventNotification,
    )
    from stripe.events._v1_payout_reconciliation_completed_event import (
        V1PayoutReconciliationCompletedEventNotification,
    )
    from stripe.events._v1_payout_updated_event import (
        V1PayoutUpdatedEventNotification,
    )
    from stripe.events._v1_person_created_event import (
        V1PersonCreatedEventNotification,
    )
    from stripe.events._v1_person_deleted_event import (
        V1PersonDeletedEventNotification,
    )
    from stripe.events._v1_person_updated_event import (
        V1PersonUpdatedEventNotification,
    )
    from stripe.events._v1_plan_created_event import (
        V1PlanCreatedEventNotification,
    )
    from stripe.events._v1_plan_deleted_event import (
        V1PlanDeletedEventNotification,
    )
    from stripe.events._v1_plan_updated_event import (
        V1PlanUpdatedEventNotification,
    )
    from stripe.events._v1_price_activated_event import (
        V1PriceActivatedEventNotification,
    )
    from stripe.events._v1_price_created_event import (
        V1PriceCreatedEventNotification,
    )
    from stripe.events._v1_price_deactivated_event import (
        V1PriceDeactivatedEventNotification,
    )
    from stripe.events._v1_price_deleted_event import (
        V1PriceDeletedEventNotification,
    )
    from stripe.events._v1_price_lookup_key_changed_event import (
        V1PriceLookupKeyChangedEventNotification,
    )
    from stripe.events._v1_price_tax_behavior_changed_event import (
        V1PriceTaxBehaviorChangedEventNotification,
    )
    from stripe.events._v1_price_updated_event import (
        V1PriceUpdatedEventNotification,
    )
    from stripe.events._v1_product_activated_event import (
        V1ProductActivatedEventNotification,
    )
    from stripe.events._v1_product_created_event import (
        V1ProductCreatedEventNotification,
    )
    from stripe.events._v1_product_deactivated_event import (
        V1ProductDeactivatedEventNotification,
    )
    from stripe.events._v1_product_default_price_changed_event import (
        V1ProductDefaultPriceChangedEventNotification,
    )
    from stripe.events._v1_product_deleted_event import (
        V1ProductDeletedEventNotification,
    )
    from stripe.events._v1_product_tax_code_changed_event import (
        V1ProductTaxCodeChangedEventNotification,
    )
    from stripe.events._v1_product_updated_event import (
        V1ProductUpdatedEventNotification,
    )
    from stripe.events._v1_promotion_code_created_event import (
        V1PromotionCodeCreatedEventNotification,
    )
    from stripe.events._v1_promotion_code_fully_redeemed_event import (
        V1PromotionCodeFullyRedeemedEventNotification,
    )
    from stripe.events._v1_promotion_code_updated_event import (
        V1PromotionCodeUpdatedEventNotification,
    )
    from stripe.events._v1_quote_accepted_event import (
        V1QuoteAcceptedEventNotification,
    )
    from stripe.events._v1_quote_canceled_event import (
        V1QuoteCanceledEventNotification,
    )
    from stripe.events._v1_quote_created_event import (
        V1QuoteCreatedEventNotification,
    )
    from stripe.events._v1_quote_finalized_event import (
        V1QuoteFinalizedEventNotification,
    )
    from stripe.events._v1_radar_early_fraud_warning_created_event import (
        V1RadarEarlyFraudWarningCreatedEventNotification,
    )
    from stripe.events._v1_radar_early_fraud_warning_updated_event import (
        V1RadarEarlyFraudWarningUpdatedEventNotification,
    )
    from stripe.events._v1_refund_created_event import (
        V1RefundCreatedEventNotification,
    )
    from stripe.events._v1_refund_failed_event import (
        V1RefundFailedEventNotification,
    )
    from stripe.events._v1_refund_updated_event import (
        V1RefundUpdatedEventNotification,
    )
    from stripe.events._v1_review_closed_event import (
        V1ReviewClosedEventNotification,
    )
    from stripe.events._v1_review_opened_event import (
        V1ReviewOpenedEventNotification,
    )
    from stripe.events._v1_setup_intent_canceled_event import (
        V1SetupIntentCanceledEventNotification,
    )
    from stripe.events._v1_setup_intent_created_event import (
        V1SetupIntentCreatedEventNotification,
    )
    from stripe.events._v1_setup_intent_requires_action_event import (
        V1SetupIntentRequiresActionEventNotification,
    )
    from stripe.events._v1_setup_intent_setup_failed_event import (
        V1SetupIntentSetupFailedEventNotification,
    )
    from stripe.events._v1_setup_intent_succeeded_event import (
        V1SetupIntentSucceededEventNotification,
    )
    from stripe.events._v1_sigma_scheduled_query_run_created_event import (
        V1SigmaScheduledQueryRunCreatedEventNotification,
    )
    from stripe.events._v1_source_canceled_event import (
        V1SourceCanceledEventNotification,
    )
    from stripe.events._v1_source_chargeable_event import (
        V1SourceChargeableEventNotification,
    )
    from stripe.events._v1_source_failed_event import (
        V1SourceFailedEventNotification,
    )
    from stripe.events._v1_source_refund_attributes_required_event import (
        V1SourceRefundAttributesRequiredEventNotification,
    )
    from stripe.events._v1_subscription_schedule_aborted_event import (
        V1SubscriptionScheduleAbortedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_canceled_event import (
        V1SubscriptionScheduleCanceledEventNotification,
    )
    from stripe.events._v1_subscription_schedule_completed_event import (
        V1SubscriptionScheduleCompletedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_created_event import (
        V1SubscriptionScheduleCreatedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_expiring_event import (
        V1SubscriptionScheduleExpiringEventNotification,
    )
    from stripe.events._v1_subscription_schedule_phase_added_event import (
        V1SubscriptionSchedulePhaseAddedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_phase_default_tax_rates_changed_event import (
        V1SubscriptionSchedulePhaseDefaultTaxRatesChangedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_phase_end_date_changed_event import (
        V1SubscriptionSchedulePhaseEndDateChangedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_phase_removed_event import (
        V1SubscriptionSchedulePhaseRemovedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_phase_trial_end_changed_event import (
        V1SubscriptionSchedulePhaseTrialEndChangedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_released_event import (
        V1SubscriptionScheduleReleasedEventNotification,
    )
    from stripe.events._v1_subscription_schedule_updated_event import (
        V1SubscriptionScheduleUpdatedEventNotification,
    )
    from stripe.events._v1_tax_rate_created_event import (
        V1TaxRateCreatedEventNotification,
    )
    from stripe.events._v1_tax_rate_updated_event import (
        V1TaxRateUpdatedEventNotification,
    )
    from stripe.events._v1_tax_settings_updated_event import (
        V1TaxSettingsUpdatedEventNotification,
    )
    from stripe.events._v1_terminal_reader_action_failed_event import (
        V1TerminalReaderActionFailedEventNotification,
    )
    from stripe.events._v1_terminal_reader_action_succeeded_event import (
        V1TerminalReaderActionSucceededEventNotification,
    )
    from stripe.events._v1_terminal_reader_action_updated_event import (
        V1TerminalReaderActionUpdatedEventNotification,
    )
    from stripe.events._v1_test_helpers_test_clock_advancing_event import (
        V1TestHelpersTestClockAdvancingEventNotification,
    )
    from stripe.events._v1_test_helpers_test_clock_created_event import (
        V1TestHelpersTestClockCreatedEventNotification,
    )
    from stripe.events._v1_test_helpers_test_clock_deleted_event import (
        V1TestHelpersTestClockDeletedEventNotification,
    )
    from stripe.events._v1_test_helpers_test_clock_internal_failure_event import (
        V1TestHelpersTestClockInternalFailureEventNotification,
    )
    from stripe.events._v1_test_helpers_test_clock_ready_event import (
        V1TestHelpersTestClockReadyEventNotification,
    )
    from stripe.events._v1_topup_canceled_event import (
        V1TopupCanceledEventNotification,
    )
    from stripe.events._v1_topup_created_event import (
        V1TopupCreatedEventNotification,
    )
    from stripe.events._v1_topup_failed_event import (
        V1TopupFailedEventNotification,
    )
    from stripe.events._v1_topup_reversed_event import (
        V1TopupReversedEventNotification,
    )
    from stripe.events._v1_topup_succeeded_event import (
        V1TopupSucceededEventNotification,
    )
    from stripe.events._v1_transfer_created_event import (
        V1TransferCreatedEventNotification,
    )
    from stripe.events._v1_transfer_reversed_event import (
        V1TransferReversedEventNotification,
    )
    from stripe.events._v1_transfer_updated_event import (
        V1TransferUpdatedEventNotification,
    )
    from stripe.events._v2_commerce_product_catalog_imports_failed_event import (
        V2CommerceProductCatalogImportsFailedEventNotification,
    )
    from stripe.events._v2_commerce_product_catalog_imports_processing_event import (
        V2CommerceProductCatalogImportsProcessingEventNotification,
    )
    from stripe.events._v2_commerce_product_catalog_imports_succeeded_event import (
        V2CommerceProductCatalogImportsSucceededEventNotification,
    )
    from stripe.events._v2_commerce_product_catalog_imports_succeeded_with_errors_event import (
        V2CommerceProductCatalogImportsSucceededWithErrorsEventNotification,
    )
    from stripe.events._v2_core_account_closed_event import (
        V2CoreAccountClosedEventNotification,
    )
    from stripe.events._v2_core_account_created_event import (
        V2CoreAccountCreatedEventNotification,
    )
    from stripe.events._v2_core_account_including_configuration_customer_capability_status_updated_event import (
        V2CoreAccountIncludingConfigurationCustomerCapabilityStatusUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_configuration_customer_updated_event import (
        V2CoreAccountIncludingConfigurationCustomerUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_configuration_merchant_capability_status_updated_event import (
        V2CoreAccountIncludingConfigurationMerchantCapabilityStatusUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_configuration_merchant_updated_event import (
        V2CoreAccountIncludingConfigurationMerchantUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_configuration_recipient_capability_status_updated_event import (
        V2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_configuration_recipient_updated_event import (
        V2CoreAccountIncludingConfigurationRecipientUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_defaults_updated_event import (
        V2CoreAccountIncludingDefaultsUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_future_requirements_updated_event import (
        V2CoreAccountIncludingFutureRequirementsUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_identity_updated_event import (
        V2CoreAccountIncludingIdentityUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_including_requirements_updated_event import (
        V2CoreAccountIncludingRequirementsUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_link_returned_event import (
        V2CoreAccountLinkReturnedEventNotification,
    )
    from stripe.events._v2_core_account_person_created_event import (
        V2CoreAccountPersonCreatedEventNotification,
    )
    from stripe.events._v2_core_account_person_deleted_event import (
        V2CoreAccountPersonDeletedEventNotification,
    )
    from stripe.events._v2_core_account_person_updated_event import (
        V2CoreAccountPersonUpdatedEventNotification,
    )
    from stripe.events._v2_core_account_updated_event import (
        V2CoreAccountUpdatedEventNotification,
    )
    from stripe.events._v2_core_event_destination_ping_event import (
        V2CoreEventDestinationPingEventNotification,
    )
    from stripe.events._v2_money_management_adjustment_created_event import (
        V2MoneyManagementAdjustmentCreatedEventNotification,
    )
    from stripe.events._v2_money_management_financial_account_created_event import (
        V2MoneyManagementFinancialAccountCreatedEventNotification,
    )
    from stripe.events._v2_money_management_financial_account_updated_event import (
        V2MoneyManagementFinancialAccountUpdatedEventNotification,
    )
    from stripe.events._v2_money_management_financial_address_activated_event import (
        V2MoneyManagementFinancialAddressActivatedEventNotification,
    )
    from stripe.events._v2_money_management_financial_address_failed_event import (
        V2MoneyManagementFinancialAddressFailedEventNotification,
    )
    from stripe.events._v2_money_management_inbound_transfer_available_event import (
        V2MoneyManagementInboundTransferAvailableEventNotification,
    )
    from stripe.events._v2_money_management_inbound_transfer_bank_debit_failed_event import (
        V2MoneyManagementInboundTransferBankDebitFailedEventNotification,
    )
    from stripe.events._v2_money_management_inbound_transfer_bank_debit_processing_event import (
        V2MoneyManagementInboundTransferBankDebitProcessingEventNotification,
    )
    from stripe.events._v2_money_management_inbound_transfer_bank_debit_queued_event import (
        V2MoneyManagementInboundTransferBankDebitQueuedEventNotification,
    )
    from stripe.events._v2_money_management_inbound_transfer_bank_debit_returned_event import (
        V2MoneyManagementInboundTransferBankDebitReturnedEventNotification,
    )
    from stripe.events._v2_money_management_inbound_transfer_bank_debit_succeeded_event import (
        V2MoneyManagementInboundTransferBankDebitSucceededEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_canceled_event import (
        V2MoneyManagementOutboundPaymentCanceledEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_created_event import (
        V2MoneyManagementOutboundPaymentCreatedEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_failed_event import (
        V2MoneyManagementOutboundPaymentFailedEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_posted_event import (
        V2MoneyManagementOutboundPaymentPostedEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_returned_event import (
        V2MoneyManagementOutboundPaymentReturnedEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_under_review_event import (
        V2MoneyManagementOutboundPaymentUnderReviewEventNotification,
    )
    from stripe.events._v2_money_management_outbound_payment_updated_event import (
        V2MoneyManagementOutboundPaymentUpdatedEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_canceled_event import (
        V2MoneyManagementPayoutIntentCanceledEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_created_event import (
        V2MoneyManagementPayoutIntentCreatedEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_pending_event import (
        V2MoneyManagementPayoutIntentPendingEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_posted_event import (
        V2MoneyManagementPayoutIntentPostedEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_processing_event import (
        V2MoneyManagementPayoutIntentProcessingEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_requires_action_event import (
        V2MoneyManagementPayoutIntentRequiresActionEventNotification,
    )
    from stripe.events._v2_money_management_payout_intent_updated_event import (
        V2MoneyManagementPayoutIntentUpdatedEventNotification,
    )
    from stripe.events._v2_money_management_payout_method_created_event import (
        V2MoneyManagementPayoutMethodCreatedEventNotification,
    )
    from stripe.events._v2_money_management_payout_method_updated_event import (
        V2MoneyManagementPayoutMethodUpdatedEventNotification,
    )
    from stripe.events._v2_money_management_received_credit_available_event import (
        V2MoneyManagementReceivedCreditAvailableEventNotification,
    )
    from stripe.events._v2_money_management_received_credit_failed_event import (
        V2MoneyManagementReceivedCreditFailedEventNotification,
    )
    from stripe.events._v2_money_management_received_credit_returned_event import (
        V2MoneyManagementReceivedCreditReturnedEventNotification,
    )
    from stripe.events._v2_money_management_received_credit_succeeded_event import (
        V2MoneyManagementReceivedCreditSucceededEventNotification,
    )
    from stripe.events._v2_money_management_recipient_verification_created_event import (
        V2MoneyManagementRecipientVerificationCreatedEventNotification,
    )
    from stripe.events._v2_money_management_recipient_verification_updated_event import (
        V2MoneyManagementRecipientVerificationUpdatedEventNotification,
    )
    from stripe.events._v2_money_management_transaction_created_event import (
        V2MoneyManagementTransactionCreatedEventNotification,
    )
    from stripe.events._v2_money_management_transaction_updated_event import (
        V2MoneyManagementTransactionUpdatedEventNotification,
    )
    # event-notification-types: The end of the section generated from our OpenAPI spec

# internal type to represent any EventNotification subclass
EventNotificationChild = TypeVar(
    "EventNotificationChild", bound="EventNotification"
)


@dataclass
class UnhandledNotificationDetails:
    """
    Information about an unhandled event notification to make it easier to respond (and potentially update your integration).
    """

    is_known_event_type: bool
    """
    If true, the unhandled event's type is known to the SDK (i.e., it was successfully deserialized into a specific `EventNotification` subclass).
    """


# The handler base class is generic over what its callbacks return, which lets us reuse base classes for both the sync and async handlers.
CallbackReturn = TypeVar("CallbackReturn")
PreHandleReturn = TypeVar("PreHandleReturn")

_FallbackCallback = Callable[
    [EventNotification, "StripeClient", UnhandledNotificationDetails],
    CallbackReturn,
]

_PreHandleCallback = Callable[
    [EventNotification, "StripeClient"], PreHandleReturn
]

FallbackCallback = _FallbackCallback[None]
"""
Called when no other callback is registered for a given event notification type.
"""

AsyncFallbackCallback = _FallbackCallback[Awaitable[None]]
"""
This async function is called when no other callback is registered for a given event notification type.
"""

PreHandleCallback = _PreHandleCallback[bool]
"""
Called before any of your callbacks are run. Useful for filtering.
"""

AsyncPreHandleCallback = _PreHandleCallback[Awaitable[bool]]
"""
This async function is called before any of your callbacks are run. Useful for filtering.
"""


class _BaseEventNotificationHandler(Generic[CallbackReturn, PreHandleReturn]):
    """
    Shared internal registration machinery for the user-facing event handlers.

    Holds everything that doesn't depend on whether callbacks are awaited; the
    sync and async subclasses below add only the dispatch loop itself.
    """

    def __init__(
        self,
        client: "StripeClient",
        fallback_callback: _FallbackCallback[CallbackReturn],
    ) -> None:
        self._registered_handlers = {}
        self._client = client
        self.fallback_callback = fallback_callback
        # once this is true, adding additional handlers results in an error
        self._has_handled_events = False
        self._pre_handle_callback: Optional[
            _PreHandleCallback[PreHandleReturn]
        ] = None

    def _assert_hasnt_handled(self) -> None:
        """
        Callbacks are expected to be registered on startup, so registering anything after handling an event indicates a bug.
        """
        if self._has_handled_events:
            raise RuntimeError(
                "Cannot register new callbacks after an event has been handled. This is indicative of a bug."
            )

    def pre_handle(
        self, func: _PreHandleCallback[PreHandleReturn]
    ) -> _PreHandleCallback[PreHandleReturn]:
        """
        Registers a function that will be run before any event-specific callbacks. A useful place to store event-agnostic logic, such as logging or checking for [duplicate event deliveries](https://docs.stripe.com/webhooks#handle-duplicate-events).

        Returning `True` causes handling to continue as normal; returning `False` returns from `.handle()` immediately, so neither the registered callback nor the fallback callback are called.
        """
        self._assert_hasnt_handled()
        if self._pre_handle_callback:
            raise ValueError("A pre_handle callback is already registered")

        self._pre_handle_callback = func
        return func

    def _callback_for(self, event_notif: "EventNotification"):
        """
        Returns the callback registered for this event's type, if any.
        """
        return self._registered_handlers.get(event_notif.type)

    def _unhandled_details(
        self, event_notif: "EventNotification"
    ) -> UnhandledNotificationDetails:
        return UnhandledNotificationDetails(
            is_known_event_type=not isinstance(
                event_notif, UnknownEventNotification
            )
        )

    def _register(
        self,
        event_type: str,
        func: "Callable[[EventNotificationChild, StripeClient], CallbackReturn]",
    ) -> None:
        self._assert_hasnt_handled()
        if event_type in self._registered_handlers:
            raise ValueError(
                f'Callback for event type "{event_type}" is already registered'
            )

        self._registered_handlers[event_type] = func

    @property
    def registered_event_types(self) -> List[str]:
        """
        Returns an alphabetized list of all event types that have registered handlers.
        """
        return sorted(self._registered_handlers.keys())

    # event-notification-registration-methods: The beginning of the section generated from our OpenAPI spec
    def on_v1_account_application_authorized(
        self,
        func: "Callable[[V1AccountApplicationAuthorizedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1AccountApplicationAuthorizedEvent` (`v1.account.application.authorized`) event notification.
        """
        self._register(
            "v1.account.application.authorized",
            func,
        )
        return func

    def on_v1_account_application_deauthorized(
        self,
        func: "Callable[[V1AccountApplicationDeauthorizedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1AccountApplicationDeauthorizedEvent` (`v1.account.application.deauthorized`) event notification.
        """
        self._register(
            "v1.account.application.deauthorized",
            func,
        )
        return func

    def on_v1_account_external_account_created(
        self,
        func: "Callable[[V1AccountExternalAccountCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1AccountExternalAccountCreatedEvent` (`v1.account.external_account.created`) event notification.
        """
        self._register(
            "v1.account.external_account.created",
            func,
        )
        return func

    def on_v1_account_external_account_deleted(
        self,
        func: "Callable[[V1AccountExternalAccountDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1AccountExternalAccountDeletedEvent` (`v1.account.external_account.deleted`) event notification.
        """
        self._register(
            "v1.account.external_account.deleted",
            func,
        )
        return func

    def on_v1_account_external_account_updated(
        self,
        func: "Callable[[V1AccountExternalAccountUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1AccountExternalAccountUpdatedEvent` (`v1.account.external_account.updated`) event notification.
        """
        self._register(
            "v1.account.external_account.updated",
            func,
        )
        return func

    def on_v1_account_updated(
        self,
        func: "Callable[[V1AccountUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1AccountUpdatedEvent` (`v1.account.updated`) event notification.
        """
        self._register(
            "v1.account.updated",
            func,
        )
        return func

    def on_v1_application_fee_created(
        self,
        func: "Callable[[V1ApplicationFeeCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ApplicationFeeCreatedEvent` (`v1.application_fee.created`) event notification.
        """
        self._register(
            "v1.application_fee.created",
            func,
        )
        return func

    def on_v1_application_fee_refunded(
        self,
        func: "Callable[[V1ApplicationFeeRefundedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ApplicationFeeRefundedEvent` (`v1.application_fee.refunded`) event notification.
        """
        self._register(
            "v1.application_fee.refunded",
            func,
        )
        return func

    def on_v1_application_fee_refund_updated(
        self,
        func: "Callable[[V1ApplicationFeeRefundUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ApplicationFeeRefundUpdatedEvent` (`v1.application_fee.refund.updated`) event notification.
        """
        self._register(
            "v1.application_fee.refund.updated",
            func,
        )
        return func

    def on_v1_balance_available(
        self,
        func: "Callable[[V1BalanceAvailableEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BalanceAvailableEvent` (`v1.balance.available`) event notification.
        """
        self._register(
            "v1.balance.available",
            func,
        )
        return func

    def on_v1_balance_settings_updated(
        self,
        func: "Callable[[V1BalanceSettingsUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BalanceSettingsUpdatedEvent` (`v1.balance_settings.updated`) event notification.
        """
        self._register(
            "v1.balance_settings.updated",
            func,
        )
        return func

    def on_v1_billing_alert_triggered(
        self,
        func: "Callable[[V1BillingAlertTriggeredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingAlertTriggeredEvent` (`v1.billing.alert.triggered`) event notification.
        """
        self._register(
            "v1.billing.alert.triggered",
            func,
        )
        return func

    def on_v1_billing_credit_balance_transaction_created(
        self,
        func: "Callable[[V1BillingCreditBalanceTransactionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingCreditBalanceTransactionCreatedEvent` (`v1.billing.credit_balance_transaction.created`) event notification.
        """
        self._register(
            "v1.billing.credit_balance_transaction.created",
            func,
        )
        return func

    def on_v1_billing_credit_grant_created(
        self,
        func: "Callable[[V1BillingCreditGrantCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingCreditGrantCreatedEvent` (`v1.billing.credit_grant.created`) event notification.
        """
        self._register(
            "v1.billing.credit_grant.created",
            func,
        )
        return func

    def on_v1_billing_credit_grant_updated(
        self,
        func: "Callable[[V1BillingCreditGrantUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingCreditGrantUpdatedEvent` (`v1.billing.credit_grant.updated`) event notification.
        """
        self._register(
            "v1.billing.credit_grant.updated",
            func,
        )
        return func

    def on_v1_billing_meter_created(
        self,
        func: "Callable[[V1BillingMeterCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingMeterCreatedEvent` (`v1.billing.meter.created`) event notification.
        """
        self._register(
            "v1.billing.meter.created",
            func,
        )
        return func

    def on_v1_billing_meter_deactivated(
        self,
        func: "Callable[[V1BillingMeterDeactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingMeterDeactivatedEvent` (`v1.billing.meter.deactivated`) event notification.
        """
        self._register(
            "v1.billing.meter.deactivated",
            func,
        )
        return func

    def on_v1_billing_meter_error_report_triggered(
        self,
        func: "Callable[[V1BillingMeterErrorReportTriggeredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingMeterErrorReportTriggeredEvent` (`v1.billing.meter.error_report_triggered`) event notification.
        """
        self._register(
            "v1.billing.meter.error_report_triggered",
            func,
        )
        return func

    def on_v1_billing_meter_no_meter_found(
        self,
        func: "Callable[[V1BillingMeterNoMeterFoundEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingMeterNoMeterFoundEvent` (`v1.billing.meter.no_meter_found`) event notification.
        """
        self._register(
            "v1.billing.meter.no_meter_found",
            func,
        )
        return func

    def on_v1_billing_meter_reactivated(
        self,
        func: "Callable[[V1BillingMeterReactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingMeterReactivatedEvent` (`v1.billing.meter.reactivated`) event notification.
        """
        self._register(
            "v1.billing.meter.reactivated",
            func,
        )
        return func

    def on_v1_billing_meter_updated(
        self,
        func: "Callable[[V1BillingMeterUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingMeterUpdatedEvent` (`v1.billing.meter.updated`) event notification.
        """
        self._register(
            "v1.billing.meter.updated",
            func,
        )
        return func

    def on_v1_billing_portal_configuration_created(
        self,
        func: "Callable[[V1BillingPortalConfigurationCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingPortalConfigurationCreatedEvent` (`v1.billing_portal.configuration.created`) event notification.
        """
        self._register(
            "v1.billing_portal.configuration.created",
            func,
        )
        return func

    def on_v1_billing_portal_configuration_updated(
        self,
        func: "Callable[[V1BillingPortalConfigurationUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingPortalConfigurationUpdatedEvent` (`v1.billing_portal.configuration.updated`) event notification.
        """
        self._register(
            "v1.billing_portal.configuration.updated",
            func,
        )
        return func

    def on_v1_billing_portal_session_created(
        self,
        func: "Callable[[V1BillingPortalSessionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1BillingPortalSessionCreatedEvent` (`v1.billing_portal.session.created`) event notification.
        """
        self._register(
            "v1.billing_portal.session.created",
            func,
        )
        return func

    def on_v1_capability_updated(
        self,
        func: "Callable[[V1CapabilityUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CapabilityUpdatedEvent` (`v1.capability.updated`) event notification.
        """
        self._register(
            "v1.capability.updated",
            func,
        )
        return func

    def on_v1_cash_balance_funds_available(
        self,
        func: "Callable[[V1CashBalanceFundsAvailableEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CashBalanceFundsAvailableEvent` (`v1.cash_balance.funds_available`) event notification.
        """
        self._register(
            "v1.cash_balance.funds_available",
            func,
        )
        return func

    def on_v1_charge_captured(
        self,
        func: "Callable[[V1ChargeCapturedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeCapturedEvent` (`v1.charge.captured`) event notification.
        """
        self._register(
            "v1.charge.captured",
            func,
        )
        return func

    def on_v1_charge_dispute_closed(
        self,
        func: "Callable[[V1ChargeDisputeClosedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeDisputeClosedEvent` (`v1.charge.dispute.closed`) event notification.
        """
        self._register(
            "v1.charge.dispute.closed",
            func,
        )
        return func

    def on_v1_charge_dispute_created(
        self,
        func: "Callable[[V1ChargeDisputeCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeDisputeCreatedEvent` (`v1.charge.dispute.created`) event notification.
        """
        self._register(
            "v1.charge.dispute.created",
            func,
        )
        return func

    def on_v1_charge_dispute_funds_reinstated(
        self,
        func: "Callable[[V1ChargeDisputeFundsReinstatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeDisputeFundsReinstatedEvent` (`v1.charge.dispute.funds_reinstated`) event notification.
        """
        self._register(
            "v1.charge.dispute.funds_reinstated",
            func,
        )
        return func

    def on_v1_charge_dispute_funds_withdrawn(
        self,
        func: "Callable[[V1ChargeDisputeFundsWithdrawnEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeDisputeFundsWithdrawnEvent` (`v1.charge.dispute.funds_withdrawn`) event notification.
        """
        self._register(
            "v1.charge.dispute.funds_withdrawn",
            func,
        )
        return func

    def on_v1_charge_dispute_updated(
        self,
        func: "Callable[[V1ChargeDisputeUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeDisputeUpdatedEvent` (`v1.charge.dispute.updated`) event notification.
        """
        self._register(
            "v1.charge.dispute.updated",
            func,
        )
        return func

    def on_v1_charge_expired(
        self,
        func: "Callable[[V1ChargeExpiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeExpiredEvent` (`v1.charge.expired`) event notification.
        """
        self._register(
            "v1.charge.expired",
            func,
        )
        return func

    def on_v1_charge_failed(
        self,
        func: "Callable[[V1ChargeFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeFailedEvent` (`v1.charge.failed`) event notification.
        """
        self._register(
            "v1.charge.failed",
            func,
        )
        return func

    def on_v1_charge_pending(
        self,
        func: "Callable[[V1ChargePendingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargePendingEvent` (`v1.charge.pending`) event notification.
        """
        self._register(
            "v1.charge.pending",
            func,
        )
        return func

    def on_v1_charge_refunded(
        self,
        func: "Callable[[V1ChargeRefundedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeRefundedEvent` (`v1.charge.refunded`) event notification.
        """
        self._register(
            "v1.charge.refunded",
            func,
        )
        return func

    def on_v1_charge_refund_updated(
        self,
        func: "Callable[[V1ChargeRefundUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeRefundUpdatedEvent` (`v1.charge.refund.updated`) event notification.
        """
        self._register(
            "v1.charge.refund.updated",
            func,
        )
        return func

    def on_v1_charge_succeeded(
        self,
        func: "Callable[[V1ChargeSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeSucceededEvent` (`v1.charge.succeeded`) event notification.
        """
        self._register(
            "v1.charge.succeeded",
            func,
        )
        return func

    def on_v1_charge_updated(
        self,
        func: "Callable[[V1ChargeUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ChargeUpdatedEvent` (`v1.charge.updated`) event notification.
        """
        self._register(
            "v1.charge.updated",
            func,
        )
        return func

    def on_v1_checkout_session_async_payment_failed(
        self,
        func: "Callable[[V1CheckoutSessionAsyncPaymentFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CheckoutSessionAsyncPaymentFailedEvent` (`v1.checkout.session.async_payment_failed`) event notification.
        """
        self._register(
            "v1.checkout.session.async_payment_failed",
            func,
        )
        return func

    def on_v1_checkout_session_async_payment_succeeded(
        self,
        func: "Callable[[V1CheckoutSessionAsyncPaymentSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CheckoutSessionAsyncPaymentSucceededEvent` (`v1.checkout.session.async_payment_succeeded`) event notification.
        """
        self._register(
            "v1.checkout.session.async_payment_succeeded",
            func,
        )
        return func

    def on_v1_checkout_session_completed(
        self,
        func: "Callable[[V1CheckoutSessionCompletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CheckoutSessionCompletedEvent` (`v1.checkout.session.completed`) event notification.
        """
        self._register(
            "v1.checkout.session.completed",
            func,
        )
        return func

    def on_v1_checkout_session_expired(
        self,
        func: "Callable[[V1CheckoutSessionExpiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CheckoutSessionExpiredEvent` (`v1.checkout.session.expired`) event notification.
        """
        self._register(
            "v1.checkout.session.expired",
            func,
        )
        return func

    def on_v1_climate_order_canceled(
        self,
        func: "Callable[[V1ClimateOrderCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateOrderCanceledEvent` (`v1.climate.order.canceled`) event notification.
        """
        self._register(
            "v1.climate.order.canceled",
            func,
        )
        return func

    def on_v1_climate_order_created(
        self,
        func: "Callable[[V1ClimateOrderCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateOrderCreatedEvent` (`v1.climate.order.created`) event notification.
        """
        self._register(
            "v1.climate.order.created",
            func,
        )
        return func

    def on_v1_climate_order_delayed(
        self,
        func: "Callable[[V1ClimateOrderDelayedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateOrderDelayedEvent` (`v1.climate.order.delayed`) event notification.
        """
        self._register(
            "v1.climate.order.delayed",
            func,
        )
        return func

    def on_v1_climate_order_delivered(
        self,
        func: "Callable[[V1ClimateOrderDeliveredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateOrderDeliveredEvent` (`v1.climate.order.delivered`) event notification.
        """
        self._register(
            "v1.climate.order.delivered",
            func,
        )
        return func

    def on_v1_climate_order_product_substituted(
        self,
        func: "Callable[[V1ClimateOrderProductSubstitutedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateOrderProductSubstitutedEvent` (`v1.climate.order.product_substituted`) event notification.
        """
        self._register(
            "v1.climate.order.product_substituted",
            func,
        )
        return func

    def on_v1_climate_product_created(
        self,
        func: "Callable[[V1ClimateProductCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateProductCreatedEvent` (`v1.climate.product.created`) event notification.
        """
        self._register(
            "v1.climate.product.created",
            func,
        )
        return func

    def on_v1_climate_product_pricing_updated(
        self,
        func: "Callable[[V1ClimateProductPricingUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ClimateProductPricingUpdatedEvent` (`v1.climate.product.pricing_updated`) event notification.
        """
        self._register(
            "v1.climate.product.pricing_updated",
            func,
        )
        return func

    def on_v1_coupon_created(
        self,
        func: "Callable[[V1CouponCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CouponCreatedEvent` (`v1.coupon.created`) event notification.
        """
        self._register(
            "v1.coupon.created",
            func,
        )
        return func

    def on_v1_coupon_deleted(
        self,
        func: "Callable[[V1CouponDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CouponDeletedEvent` (`v1.coupon.deleted`) event notification.
        """
        self._register(
            "v1.coupon.deleted",
            func,
        )
        return func

    def on_v1_coupon_updated(
        self,
        func: "Callable[[V1CouponUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CouponUpdatedEvent` (`v1.coupon.updated`) event notification.
        """
        self._register(
            "v1.coupon.updated",
            func,
        )
        return func

    def on_v1_credit_note_created(
        self,
        func: "Callable[[V1CreditNoteCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CreditNoteCreatedEvent` (`v1.credit_note.created`) event notification.
        """
        self._register(
            "v1.credit_note.created",
            func,
        )
        return func

    def on_v1_credit_note_updated(
        self,
        func: "Callable[[V1CreditNoteUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CreditNoteUpdatedEvent` (`v1.credit_note.updated`) event notification.
        """
        self._register(
            "v1.credit_note.updated",
            func,
        )
        return func

    def on_v1_credit_note_voided(
        self,
        func: "Callable[[V1CreditNoteVoidedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CreditNoteVoidedEvent` (`v1.credit_note.voided`) event notification.
        """
        self._register(
            "v1.credit_note.voided",
            func,
        )
        return func

    def on_v1_customer_cash_balance_transaction_created(
        self,
        func: "Callable[[V1CustomerCashBalanceTransactionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerCashBalanceTransactionCreatedEvent` (`v1.customer_cash_balance_transaction.created`) event notification.
        """
        self._register(
            "v1.customer_cash_balance_transaction.created",
            func,
        )
        return func

    def on_v1_customer_created(
        self,
        func: "Callable[[V1CustomerCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerCreatedEvent` (`v1.customer.created`) event notification.
        """
        self._register(
            "v1.customer.created",
            func,
        )
        return func

    def on_v1_customer_deleted(
        self,
        func: "Callable[[V1CustomerDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerDeletedEvent` (`v1.customer.deleted`) event notification.
        """
        self._register(
            "v1.customer.deleted",
            func,
        )
        return func

    def on_v1_customer_discount_created(
        self,
        func: "Callable[[V1CustomerDiscountCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerDiscountCreatedEvent` (`v1.customer.discount.created`) event notification.
        """
        self._register(
            "v1.customer.discount.created",
            func,
        )
        return func

    def on_v1_customer_discount_deleted(
        self,
        func: "Callable[[V1CustomerDiscountDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerDiscountDeletedEvent` (`v1.customer.discount.deleted`) event notification.
        """
        self._register(
            "v1.customer.discount.deleted",
            func,
        )
        return func

    def on_v1_customer_discount_source_changed(
        self,
        func: "Callable[[V1CustomerDiscountSourceChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerDiscountSourceChangedEvent` (`v1.customer.discount.source_changed`) event notification.
        """
        self._register(
            "v1.customer.discount.source_changed",
            func,
        )
        return func

    def on_v1_customer_discount_updated(
        self,
        func: "Callable[[V1CustomerDiscountUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerDiscountUpdatedEvent` (`v1.customer.discount.updated`) event notification.
        """
        self._register(
            "v1.customer.discount.updated",
            func,
        )
        return func

    def on_v1_customer_subscription_active(
        self,
        func: "Callable[[V1CustomerSubscriptionActiveEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionActiveEvent` (`v1.customer.subscription.active`) event notification.
        """
        self._register(
            "v1.customer.subscription.active",
            func,
        )
        return func

    def on_v1_customer_subscription_cancel_at_changed(
        self,
        func: "Callable[[V1CustomerSubscriptionCancelAtChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionCancelAtChangedEvent` (`v1.customer.subscription.cancel_at_changed`) event notification.
        """
        self._register(
            "v1.customer.subscription.cancel_at_changed",
            func,
        )
        return func

    def on_v1_customer_subscription_created(
        self,
        func: "Callable[[V1CustomerSubscriptionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionCreatedEvent` (`v1.customer.subscription.created`) event notification.
        """
        self._register(
            "v1.customer.subscription.created",
            func,
        )
        return func

    def on_v1_customer_subscription_default_payment_method_changed(
        self,
        func: "Callable[[V1CustomerSubscriptionDefaultPaymentMethodChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionDefaultPaymentMethodChangedEvent` (`v1.customer.subscription.default_payment_method_changed`) event notification.
        """
        self._register(
            "v1.customer.subscription.default_payment_method_changed",
            func,
        )
        return func

    def on_v1_customer_subscription_deleted(
        self,
        func: "Callable[[V1CustomerSubscriptionDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionDeletedEvent` (`v1.customer.subscription.deleted`) event notification.
        """
        self._register(
            "v1.customer.subscription.deleted",
            func,
        )
        return func

    def on_v1_customer_subscription_incomplete(
        self,
        func: "Callable[[V1CustomerSubscriptionIncompleteEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionIncompleteEvent` (`v1.customer.subscription.incomplete`) event notification.
        """
        self._register(
            "v1.customer.subscription.incomplete",
            func,
        )
        return func

    def on_v1_customer_subscription_incomplete_expired(
        self,
        func: "Callable[[V1CustomerSubscriptionIncompleteExpiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionIncompleteExpiredEvent` (`v1.customer.subscription.incomplete_expired`) event notification.
        """
        self._register(
            "v1.customer.subscription.incomplete_expired",
            func,
        )
        return func

    def on_v1_customer_subscription_item_added(
        self,
        func: "Callable[[V1CustomerSubscriptionItemAddedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionItemAddedEvent` (`v1.customer.subscription.item_added`) event notification.
        """
        self._register(
            "v1.customer.subscription.item_added",
            func,
        )
        return func

    def on_v1_customer_subscription_item_price_changed(
        self,
        func: "Callable[[V1CustomerSubscriptionItemPriceChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionItemPriceChangedEvent` (`v1.customer.subscription.item_price_changed`) event notification.
        """
        self._register(
            "v1.customer.subscription.item_price_changed",
            func,
        )
        return func

    def on_v1_customer_subscription_item_quantity_changed(
        self,
        func: "Callable[[V1CustomerSubscriptionItemQuantityChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionItemQuantityChangedEvent` (`v1.customer.subscription.item_quantity_changed`) event notification.
        """
        self._register(
            "v1.customer.subscription.item_quantity_changed",
            func,
        )
        return func

    def on_v1_customer_subscription_item_removed(
        self,
        func: "Callable[[V1CustomerSubscriptionItemRemovedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionItemRemovedEvent` (`v1.customer.subscription.item_removed`) event notification.
        """
        self._register(
            "v1.customer.subscription.item_removed",
            func,
        )
        return func

    def on_v1_customer_subscription_item_tax_rates_changed(
        self,
        func: "Callable[[V1CustomerSubscriptionItemTaxRatesChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionItemTaxRatesChangedEvent` (`v1.customer.subscription.item_tax_rates_changed`) event notification.
        """
        self._register(
            "v1.customer.subscription.item_tax_rates_changed",
            func,
        )
        return func

    def on_v1_customer_subscription_past_due(
        self,
        func: "Callable[[V1CustomerSubscriptionPastDueEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionPastDueEvent` (`v1.customer.subscription.past_due`) event notification.
        """
        self._register(
            "v1.customer.subscription.past_due",
            func,
        )
        return func

    def on_v1_customer_subscription_paused(
        self,
        func: "Callable[[V1CustomerSubscriptionPausedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionPausedEvent` (`v1.customer.subscription.paused`) event notification.
        """
        self._register(
            "v1.customer.subscription.paused",
            func,
        )
        return func

    def on_v1_customer_subscription_pending_update_applied(
        self,
        func: "Callable[[V1CustomerSubscriptionPendingUpdateAppliedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionPendingUpdateAppliedEvent` (`v1.customer.subscription.pending_update_applied`) event notification.
        """
        self._register(
            "v1.customer.subscription.pending_update_applied",
            func,
        )
        return func

    def on_v1_customer_subscription_pending_update_expired(
        self,
        func: "Callable[[V1CustomerSubscriptionPendingUpdateExpiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionPendingUpdateExpiredEvent` (`v1.customer.subscription.pending_update_expired`) event notification.
        """
        self._register(
            "v1.customer.subscription.pending_update_expired",
            func,
        )
        return func

    def on_v1_customer_subscription_resumed(
        self,
        func: "Callable[[V1CustomerSubscriptionResumedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionResumedEvent` (`v1.customer.subscription.resumed`) event notification.
        """
        self._register(
            "v1.customer.subscription.resumed",
            func,
        )
        return func

    def on_v1_customer_subscription_trialing(
        self,
        func: "Callable[[V1CustomerSubscriptionTrialingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionTrialingEvent` (`v1.customer.subscription.trialing`) event notification.
        """
        self._register(
            "v1.customer.subscription.trialing",
            func,
        )
        return func

    def on_v1_customer_subscription_trial_will_end(
        self,
        func: "Callable[[V1CustomerSubscriptionTrialWillEndEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionTrialWillEndEvent` (`v1.customer.subscription.trial_will_end`) event notification.
        """
        self._register(
            "v1.customer.subscription.trial_will_end",
            func,
        )
        return func

    def on_v1_customer_subscription_unpaid(
        self,
        func: "Callable[[V1CustomerSubscriptionUnpaidEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionUnpaidEvent` (`v1.customer.subscription.unpaid`) event notification.
        """
        self._register(
            "v1.customer.subscription.unpaid",
            func,
        )
        return func

    def on_v1_customer_subscription_updated(
        self,
        func: "Callable[[V1CustomerSubscriptionUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerSubscriptionUpdatedEvent` (`v1.customer.subscription.updated`) event notification.
        """
        self._register(
            "v1.customer.subscription.updated",
            func,
        )
        return func

    def on_v1_customer_tax_id_created(
        self,
        func: "Callable[[V1CustomerTaxIdCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerTaxIdCreatedEvent` (`v1.customer.tax_id.created`) event notification.
        """
        self._register(
            "v1.customer.tax_id.created",
            func,
        )
        return func

    def on_v1_customer_tax_id_deleted(
        self,
        func: "Callable[[V1CustomerTaxIdDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerTaxIdDeletedEvent` (`v1.customer.tax_id.deleted`) event notification.
        """
        self._register(
            "v1.customer.tax_id.deleted",
            func,
        )
        return func

    def on_v1_customer_tax_id_updated(
        self,
        func: "Callable[[V1CustomerTaxIdUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerTaxIdUpdatedEvent` (`v1.customer.tax_id.updated`) event notification.
        """
        self._register(
            "v1.customer.tax_id.updated",
            func,
        )
        return func

    def on_v1_customer_updated(
        self,
        func: "Callable[[V1CustomerUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1CustomerUpdatedEvent` (`v1.customer.updated`) event notification.
        """
        self._register(
            "v1.customer.updated",
            func,
        )
        return func

    def on_v1_entitlements_active_entitlement_summary_entitlement_added(
        self,
        func: "Callable[[V1EntitlementsActiveEntitlementSummaryEntitlementAddedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1EntitlementsActiveEntitlementSummaryEntitlementAddedEvent` (`v1.entitlements.active_entitlement_summary.entitlement_added`) event notification.
        """
        self._register(
            "v1.entitlements.active_entitlement_summary.entitlement_added",
            func,
        )
        return func

    def on_v1_entitlements_active_entitlement_summary_entitlement_removed(
        self,
        func: "Callable[[V1EntitlementsActiveEntitlementSummaryEntitlementRemovedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1EntitlementsActiveEntitlementSummaryEntitlementRemovedEvent` (`v1.entitlements.active_entitlement_summary.entitlement_removed`) event notification.
        """
        self._register(
            "v1.entitlements.active_entitlement_summary.entitlement_removed",
            func,
        )
        return func

    def on_v1_entitlements_active_entitlement_summary_updated(
        self,
        func: "Callable[[V1EntitlementsActiveEntitlementSummaryUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1EntitlementsActiveEntitlementSummaryUpdatedEvent` (`v1.entitlements.active_entitlement_summary.updated`) event notification.
        """
        self._register(
            "v1.entitlements.active_entitlement_summary.updated",
            func,
        )
        return func

    def on_v1_file_created(
        self,
        func: "Callable[[V1FileCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FileCreatedEvent` (`v1.file.created`) event notification.
        """
        self._register(
            "v1.file.created",
            func,
        )
        return func

    def on_v1_financial_connections_account_account_numbers_updated(
        self,
        func: "Callable[[V1FinancialConnectionsAccountAccountNumbersUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountAccountNumbersUpdatedEvent` (`v1.financial_connections.account.account_numbers_updated`) event notification.
        """
        self._register(
            "v1.financial_connections.account.account_numbers_updated",
            func,
        )
        return func

    def on_v1_financial_connections_account_balance_refresh_failed(
        self,
        func: "Callable[[V1FinancialConnectionsAccountBalanceRefreshFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountBalanceRefreshFailedEvent` (`v1.financial_connections.account.balance_refresh_failed`) event notification.
        """
        self._register(
            "v1.financial_connections.account.balance_refresh_failed",
            func,
        )
        return func

    def on_v1_financial_connections_account_balance_refresh_succeeded(
        self,
        func: "Callable[[V1FinancialConnectionsAccountBalanceRefreshSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountBalanceRefreshSucceededEvent` (`v1.financial_connections.account.balance_refresh_succeeded`) event notification.
        """
        self._register(
            "v1.financial_connections.account.balance_refresh_succeeded",
            func,
        )
        return func

    def on_v1_financial_connections_account_created(
        self,
        func: "Callable[[V1FinancialConnectionsAccountCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountCreatedEvent` (`v1.financial_connections.account.created`) event notification.
        """
        self._register(
            "v1.financial_connections.account.created",
            func,
        )
        return func

    def on_v1_financial_connections_account_deactivated(
        self,
        func: "Callable[[V1FinancialConnectionsAccountDeactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountDeactivatedEvent` (`v1.financial_connections.account.deactivated`) event notification.
        """
        self._register(
            "v1.financial_connections.account.deactivated",
            func,
        )
        return func

    def on_v1_financial_connections_account_disconnected(
        self,
        func: "Callable[[V1FinancialConnectionsAccountDisconnectedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountDisconnectedEvent` (`v1.financial_connections.account.disconnected`) event notification.
        """
        self._register(
            "v1.financial_connections.account.disconnected",
            func,
        )
        return func

    def on_v1_financial_connections_account_expected_deactivation_date_updated(
        self,
        func: "Callable[[V1FinancialConnectionsAccountExpectedDeactivationDateUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountExpectedDeactivationDateUpdatedEvent` (`v1.financial_connections.account.expected_deactivation_date_updated`) event notification.
        """
        self._register(
            "v1.financial_connections.account.expected_deactivation_date_updated",
            func,
        )
        return func

    def on_v1_financial_connections_account_inferred_balances_refresh_failed(
        self,
        func: "Callable[[V1FinancialConnectionsAccountInferredBalancesRefreshFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountInferredBalancesRefreshFailedEvent` (`v1.financial_connections.account.inferred_balances_refresh_failed`) event notification.
        """
        self._register(
            "v1.financial_connections.account.inferred_balances_refresh_failed",
            func,
        )
        return func

    def on_v1_financial_connections_account_inferred_balances_refresh_succeeded(
        self,
        func: "Callable[[V1FinancialConnectionsAccountInferredBalancesRefreshSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountInferredBalancesRefreshSucceededEvent` (`v1.financial_connections.account.inferred_balances_refresh_succeeded`) event notification.
        """
        self._register(
            "v1.financial_connections.account.inferred_balances_refresh_succeeded",
            func,
        )
        return func

    def on_v1_financial_connections_account_ownership_refresh_failed(
        self,
        func: "Callable[[V1FinancialConnectionsAccountOwnershipRefreshFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountOwnershipRefreshFailedEvent` (`v1.financial_connections.account.ownership_refresh_failed`) event notification.
        """
        self._register(
            "v1.financial_connections.account.ownership_refresh_failed",
            func,
        )
        return func

    def on_v1_financial_connections_account_ownership_refresh_succeeded(
        self,
        func: "Callable[[V1FinancialConnectionsAccountOwnershipRefreshSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountOwnershipRefreshSucceededEvent` (`v1.financial_connections.account.ownership_refresh_succeeded`) event notification.
        """
        self._register(
            "v1.financial_connections.account.ownership_refresh_succeeded",
            func,
        )
        return func

    def on_v1_financial_connections_account_reactivated(
        self,
        func: "Callable[[V1FinancialConnectionsAccountReactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountReactivatedEvent` (`v1.financial_connections.account.reactivated`) event notification.
        """
        self._register(
            "v1.financial_connections.account.reactivated",
            func,
        )
        return func

    def on_v1_financial_connections_account_refreshed_balance(
        self,
        func: "Callable[[V1FinancialConnectionsAccountRefreshedBalanceEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountRefreshedBalanceEvent` (`v1.financial_connections.account.refreshed_balance`) event notification.
        """
        self._register(
            "v1.financial_connections.account.refreshed_balance",
            func,
        )
        return func

    def on_v1_financial_connections_account_refreshed_ownership(
        self,
        func: "Callable[[V1FinancialConnectionsAccountRefreshedOwnershipEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountRefreshedOwnershipEvent` (`v1.financial_connections.account.refreshed_ownership`) event notification.
        """
        self._register(
            "v1.financial_connections.account.refreshed_ownership",
            func,
        )
        return func

    def on_v1_financial_connections_account_refreshed_transactions(
        self,
        func: "Callable[[V1FinancialConnectionsAccountRefreshedTransactionsEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountRefreshedTransactionsEvent` (`v1.financial_connections.account.refreshed_transactions`) event notification.
        """
        self._register(
            "v1.financial_connections.account.refreshed_transactions",
            func,
        )
        return func

    def on_v1_financial_connections_account_risk_intelligence_refresh_failed(
        self,
        func: "Callable[[V1FinancialConnectionsAccountRiskIntelligenceRefreshFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountRiskIntelligenceRefreshFailedEvent` (`v1.financial_connections.account.risk_intelligence_refresh_failed`) event notification.
        """
        self._register(
            "v1.financial_connections.account.risk_intelligence_refresh_failed",
            func,
        )
        return func

    def on_v1_financial_connections_account_risk_intelligence_refresh_succeeded(
        self,
        func: "Callable[[V1FinancialConnectionsAccountRiskIntelligenceRefreshSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountRiskIntelligenceRefreshSucceededEvent` (`v1.financial_connections.account.risk_intelligence_refresh_succeeded`) event notification.
        """
        self._register(
            "v1.financial_connections.account.risk_intelligence_refresh_succeeded",
            func,
        )
        return func

    def on_v1_financial_connections_account_supported_payment_method_types_updated(
        self,
        func: "Callable[[V1FinancialConnectionsAccountSupportedPaymentMethodTypesUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountSupportedPaymentMethodTypesUpdatedEvent` (`v1.financial_connections.account.supported_payment_method_types_updated`) event notification.
        """
        self._register(
            "v1.financial_connections.account.supported_payment_method_types_updated",
            func,
        )
        return func

    def on_v1_financial_connections_account_transactions_refresh_failed(
        self,
        func: "Callable[[V1FinancialConnectionsAccountTransactionsRefreshFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountTransactionsRefreshFailedEvent` (`v1.financial_connections.account.transactions_refresh_failed`) event notification.
        """
        self._register(
            "v1.financial_connections.account.transactions_refresh_failed",
            func,
        )
        return func

    def on_v1_financial_connections_account_transactions_refresh_succeeded(
        self,
        func: "Callable[[V1FinancialConnectionsAccountTransactionsRefreshSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountTransactionsRefreshSucceededEvent` (`v1.financial_connections.account.transactions_refresh_succeeded`) event notification.
        """
        self._register(
            "v1.financial_connections.account.transactions_refresh_succeeded",
            func,
        )
        return func

    def on_v1_financial_connections_account_upcoming_account_number_expiry(
        self,
        func: "Callable[[V1FinancialConnectionsAccountUpcomingAccountNumberExpiryEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountUpcomingAccountNumberExpiryEvent` (`v1.financial_connections.account.upcoming_account_number_expiry`) event notification.
        """
        self._register(
            "v1.financial_connections.account.upcoming_account_number_expiry",
            func,
        )
        return func

    def on_v1_financial_connections_account_upcoming_deactivation(
        self,
        func: "Callable[[V1FinancialConnectionsAccountUpcomingDeactivationEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1FinancialConnectionsAccountUpcomingDeactivationEvent` (`v1.financial_connections.account.upcoming_deactivation`) event notification.
        """
        self._register(
            "v1.financial_connections.account.upcoming_deactivation",
            func,
        )
        return func

    def on_v1_identity_verification_session_canceled(
        self,
        func: "Callable[[V1IdentityVerificationSessionCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IdentityVerificationSessionCanceledEvent` (`v1.identity.verification_session.canceled`) event notification.
        """
        self._register(
            "v1.identity.verification_session.canceled",
            func,
        )
        return func

    def on_v1_identity_verification_session_created(
        self,
        func: "Callable[[V1IdentityVerificationSessionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IdentityVerificationSessionCreatedEvent` (`v1.identity.verification_session.created`) event notification.
        """
        self._register(
            "v1.identity.verification_session.created",
            func,
        )
        return func

    def on_v1_identity_verification_session_processing(
        self,
        func: "Callable[[V1IdentityVerificationSessionProcessingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IdentityVerificationSessionProcessingEvent` (`v1.identity.verification_session.processing`) event notification.
        """
        self._register(
            "v1.identity.verification_session.processing",
            func,
        )
        return func

    def on_v1_identity_verification_session_redacted(
        self,
        func: "Callable[[V1IdentityVerificationSessionRedactedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IdentityVerificationSessionRedactedEvent` (`v1.identity.verification_session.redacted`) event notification.
        """
        self._register(
            "v1.identity.verification_session.redacted",
            func,
        )
        return func

    def on_v1_identity_verification_session_requires_input(
        self,
        func: "Callable[[V1IdentityVerificationSessionRequiresInputEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IdentityVerificationSessionRequiresInputEvent` (`v1.identity.verification_session.requires_input`) event notification.
        """
        self._register(
            "v1.identity.verification_session.requires_input",
            func,
        )
        return func

    def on_v1_identity_verification_session_verified(
        self,
        func: "Callable[[V1IdentityVerificationSessionVerifiedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IdentityVerificationSessionVerifiedEvent` (`v1.identity.verification_session.verified`) event notification.
        """
        self._register(
            "v1.identity.verification_session.verified",
            func,
        )
        return func

    def on_v1_invoice_created(
        self,
        func: "Callable[[V1InvoiceCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceCreatedEvent` (`v1.invoice.created`) event notification.
        """
        self._register(
            "v1.invoice.created",
            func,
        )
        return func

    def on_v1_invoice_deleted(
        self,
        func: "Callable[[V1InvoiceDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceDeletedEvent` (`v1.invoice.deleted`) event notification.
        """
        self._register(
            "v1.invoice.deleted",
            func,
        )
        return func

    def on_v1_invoice_discount_added(
        self,
        func: "Callable[[V1InvoiceDiscountAddedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceDiscountAddedEvent` (`v1.invoice.discount_added`) event notification.
        """
        self._register(
            "v1.invoice.discount_added",
            func,
        )
        return func

    def on_v1_invoice_discount_removed(
        self,
        func: "Callable[[V1InvoiceDiscountRemovedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceDiscountRemovedEvent` (`v1.invoice.discount_removed`) event notification.
        """
        self._register(
            "v1.invoice.discount_removed",
            func,
        )
        return func

    def on_v1_invoice_finalization_failed(
        self,
        func: "Callable[[V1InvoiceFinalizationFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceFinalizationFailedEvent` (`v1.invoice.finalization_failed`) event notification.
        """
        self._register(
            "v1.invoice.finalization_failed",
            func,
        )
        return func

    def on_v1_invoice_finalized(
        self,
        func: "Callable[[V1InvoiceFinalizedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceFinalizedEvent` (`v1.invoice.finalized`) event notification.
        """
        self._register(
            "v1.invoice.finalized",
            func,
        )
        return func

    def on_v1_invoiceitem_amount_changed(
        self,
        func: "Callable[[V1InvoiceitemAmountChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceitemAmountChangedEvent` (`v1.invoiceitem.amount_changed`) event notification.
        """
        self._register(
            "v1.invoiceitem.amount_changed",
            func,
        )
        return func

    def on_v1_invoiceitem_created(
        self,
        func: "Callable[[V1InvoiceitemCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceitemCreatedEvent` (`v1.invoiceitem.created`) event notification.
        """
        self._register(
            "v1.invoiceitem.created",
            func,
        )
        return func

    def on_v1_invoiceitem_deleted(
        self,
        func: "Callable[[V1InvoiceitemDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceitemDeletedEvent` (`v1.invoiceitem.deleted`) event notification.
        """
        self._register(
            "v1.invoiceitem.deleted",
            func,
        )
        return func

    def on_v1_invoiceitem_discount_added(
        self,
        func: "Callable[[V1InvoiceitemDiscountAddedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceitemDiscountAddedEvent` (`v1.invoiceitem.discount_added`) event notification.
        """
        self._register(
            "v1.invoiceitem.discount_added",
            func,
        )
        return func

    def on_v1_invoiceitem_discount_removed(
        self,
        func: "Callable[[V1InvoiceitemDiscountRemovedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceitemDiscountRemovedEvent` (`v1.invoiceitem.discount_removed`) event notification.
        """
        self._register(
            "v1.invoiceitem.discount_removed",
            func,
        )
        return func

    def on_v1_invoice_line_item_added(
        self,
        func: "Callable[[V1InvoiceLineItemAddedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceLineItemAddedEvent` (`v1.invoice.line_item_added`) event notification.
        """
        self._register(
            "v1.invoice.line_item_added",
            func,
        )
        return func

    def on_v1_invoice_line_item_pricing_changed(
        self,
        func: "Callable[[V1InvoiceLineItemPricingChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceLineItemPricingChangedEvent` (`v1.invoice.line_item_pricing_changed`) event notification.
        """
        self._register(
            "v1.invoice.line_item_pricing_changed",
            func,
        )
        return func

    def on_v1_invoice_line_item_quantity_changed(
        self,
        func: "Callable[[V1InvoiceLineItemQuantityChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceLineItemQuantityChangedEvent` (`v1.invoice.line_item_quantity_changed`) event notification.
        """
        self._register(
            "v1.invoice.line_item_quantity_changed",
            func,
        )
        return func

    def on_v1_invoice_line_item_removed(
        self,
        func: "Callable[[V1InvoiceLineItemRemovedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceLineItemRemovedEvent` (`v1.invoice.line_item_removed`) event notification.
        """
        self._register(
            "v1.invoice.line_item_removed",
            func,
        )
        return func

    def on_v1_invoice_marked_uncollectible(
        self,
        func: "Callable[[V1InvoiceMarkedUncollectibleEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceMarkedUncollectibleEvent` (`v1.invoice.marked_uncollectible`) event notification.
        """
        self._register(
            "v1.invoice.marked_uncollectible",
            func,
        )
        return func

    def on_v1_invoice_overdue(
        self,
        func: "Callable[[V1InvoiceOverdueEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceOverdueEvent` (`v1.invoice.overdue`) event notification.
        """
        self._register(
            "v1.invoice.overdue",
            func,
        )
        return func

    def on_v1_invoice_overpaid(
        self,
        func: "Callable[[V1InvoiceOverpaidEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceOverpaidEvent` (`v1.invoice.overpaid`) event notification.
        """
        self._register(
            "v1.invoice.overpaid",
            func,
        )
        return func

    def on_v1_invoice_paid(
        self,
        func: "Callable[[V1InvoicePaidEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaidEvent` (`v1.invoice.paid`) event notification.
        """
        self._register(
            "v1.invoice.paid",
            func,
        )
        return func

    def on_v1_invoice_payment_action_required(
        self,
        func: "Callable[[V1InvoicePaymentActionRequiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentActionRequiredEvent` (`v1.invoice.payment_action_required`) event notification.
        """
        self._register(
            "v1.invoice.payment_action_required",
            func,
        )
        return func

    def on_v1_invoice_payment_attempt_required(
        self,
        func: "Callable[[V1InvoicePaymentAttemptRequiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentAttemptRequiredEvent` (`v1.invoice.payment_attempt_required`) event notification.
        """
        self._register(
            "v1.invoice.payment_attempt_required",
            func,
        )
        return func

    def on_v1_invoice_payment_canceled(
        self,
        func: "Callable[[V1InvoicePaymentCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentCanceledEvent` (`v1.invoice_payment.canceled`) event notification.
        """
        self._register(
            "v1.invoice_payment.canceled",
            func,
        )
        return func

    def on_v1_invoice_payment_failed(
        self,
        func: "Callable[[V1InvoicePaymentFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentFailedEvent` (`v1.invoice.payment_failed`) event notification.
        """
        self._register(
            "v1.invoice.payment_failed",
            func,
        )
        return func

    def on_v1_invoice_payment_open(
        self,
        func: "Callable[[V1InvoicePaymentOpenEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentOpenEvent` (`v1.invoice_payment.open`) event notification.
        """
        self._register(
            "v1.invoice_payment.open",
            func,
        )
        return func

    def on_v1_invoice_payment_paid(
        self,
        func: "Callable[[V1InvoicePaymentPaidEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentPaidEvent` (`v1.invoice_payment.paid`) event notification.
        """
        self._register(
            "v1.invoice_payment.paid",
            func,
        )
        return func

    def on_v1_invoice_payment_succeeded(
        self,
        func: "Callable[[V1InvoicePaymentSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoicePaymentSucceededEvent` (`v1.invoice.payment_succeeded`) event notification.
        """
        self._register(
            "v1.invoice.payment_succeeded",
            func,
        )
        return func

    def on_v1_invoice_sent(
        self,
        func: "Callable[[V1InvoiceSentEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceSentEvent` (`v1.invoice.sent`) event notification.
        """
        self._register(
            "v1.invoice.sent",
            func,
        )
        return func

    def on_v1_invoice_upcoming(
        self,
        func: "Callable[[V1InvoiceUpcomingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceUpcomingEvent` (`v1.invoice.upcoming`) event notification.
        """
        self._register(
            "v1.invoice.upcoming",
            func,
        )
        return func

    def on_v1_invoice_updated(
        self,
        func: "Callable[[V1InvoiceUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceUpdatedEvent` (`v1.invoice.updated`) event notification.
        """
        self._register(
            "v1.invoice.updated",
            func,
        )
        return func

    def on_v1_invoice_voided(
        self,
        func: "Callable[[V1InvoiceVoidedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceVoidedEvent` (`v1.invoice.voided`) event notification.
        """
        self._register(
            "v1.invoice.voided",
            func,
        )
        return func

    def on_v1_invoice_will_be_due(
        self,
        func: "Callable[[V1InvoiceWillBeDueEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1InvoiceWillBeDueEvent` (`v1.invoice.will_be_due`) event notification.
        """
        self._register(
            "v1.invoice.will_be_due",
            func,
        )
        return func

    def on_v1_issuing_authorization_created(
        self,
        func: "Callable[[V1IssuingAuthorizationCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingAuthorizationCreatedEvent` (`v1.issuing_authorization.created`) event notification.
        """
        self._register(
            "v1.issuing_authorization.created",
            func,
        )
        return func

    def on_v1_issuing_authorization_request(
        self,
        func: "Callable[[V1IssuingAuthorizationRequestEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingAuthorizationRequestEvent` (`v1.issuing_authorization.request`) event notification.
        """
        self._register(
            "v1.issuing_authorization.request",
            func,
        )
        return func

    def on_v1_issuing_authorization_updated(
        self,
        func: "Callable[[V1IssuingAuthorizationUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingAuthorizationUpdatedEvent` (`v1.issuing_authorization.updated`) event notification.
        """
        self._register(
            "v1.issuing_authorization.updated",
            func,
        )
        return func

    def on_v1_issuing_card_created(
        self,
        func: "Callable[[V1IssuingCardCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingCardCreatedEvent` (`v1.issuing_card.created`) event notification.
        """
        self._register(
            "v1.issuing_card.created",
            func,
        )
        return func

    def on_v1_issuing_cardholder_created(
        self,
        func: "Callable[[V1IssuingCardholderCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingCardholderCreatedEvent` (`v1.issuing_cardholder.created`) event notification.
        """
        self._register(
            "v1.issuing_cardholder.created",
            func,
        )
        return func

    def on_v1_issuing_cardholder_updated(
        self,
        func: "Callable[[V1IssuingCardholderUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingCardholderUpdatedEvent` (`v1.issuing_cardholder.updated`) event notification.
        """
        self._register(
            "v1.issuing_cardholder.updated",
            func,
        )
        return func

    def on_v1_issuing_card_updated(
        self,
        func: "Callable[[V1IssuingCardUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingCardUpdatedEvent` (`v1.issuing_card.updated`) event notification.
        """
        self._register(
            "v1.issuing_card.updated",
            func,
        )
        return func

    def on_v1_issuing_dispute_closed(
        self,
        func: "Callable[[V1IssuingDisputeClosedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingDisputeClosedEvent` (`v1.issuing_dispute.closed`) event notification.
        """
        self._register(
            "v1.issuing_dispute.closed",
            func,
        )
        return func

    def on_v1_issuing_dispute_created(
        self,
        func: "Callable[[V1IssuingDisputeCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingDisputeCreatedEvent` (`v1.issuing_dispute.created`) event notification.
        """
        self._register(
            "v1.issuing_dispute.created",
            func,
        )
        return func

    def on_v1_issuing_dispute_funds_reinstated(
        self,
        func: "Callable[[V1IssuingDisputeFundsReinstatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingDisputeFundsReinstatedEvent` (`v1.issuing_dispute.funds_reinstated`) event notification.
        """
        self._register(
            "v1.issuing_dispute.funds_reinstated",
            func,
        )
        return func

    def on_v1_issuing_dispute_funds_rescinded(
        self,
        func: "Callable[[V1IssuingDisputeFundsRescindedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingDisputeFundsRescindedEvent` (`v1.issuing_dispute.funds_rescinded`) event notification.
        """
        self._register(
            "v1.issuing_dispute.funds_rescinded",
            func,
        )
        return func

    def on_v1_issuing_dispute_submitted(
        self,
        func: "Callable[[V1IssuingDisputeSubmittedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingDisputeSubmittedEvent` (`v1.issuing_dispute.submitted`) event notification.
        """
        self._register(
            "v1.issuing_dispute.submitted",
            func,
        )
        return func

    def on_v1_issuing_dispute_updated(
        self,
        func: "Callable[[V1IssuingDisputeUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingDisputeUpdatedEvent` (`v1.issuing_dispute.updated`) event notification.
        """
        self._register(
            "v1.issuing_dispute.updated",
            func,
        )
        return func

    def on_v1_issuing_personalization_design_activated(
        self,
        func: "Callable[[V1IssuingPersonalizationDesignActivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingPersonalizationDesignActivatedEvent` (`v1.issuing_personalization_design.activated`) event notification.
        """
        self._register(
            "v1.issuing_personalization_design.activated",
            func,
        )
        return func

    def on_v1_issuing_personalization_design_deactivated(
        self,
        func: "Callable[[V1IssuingPersonalizationDesignDeactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingPersonalizationDesignDeactivatedEvent` (`v1.issuing_personalization_design.deactivated`) event notification.
        """
        self._register(
            "v1.issuing_personalization_design.deactivated",
            func,
        )
        return func

    def on_v1_issuing_personalization_design_rejected(
        self,
        func: "Callable[[V1IssuingPersonalizationDesignRejectedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingPersonalizationDesignRejectedEvent` (`v1.issuing_personalization_design.rejected`) event notification.
        """
        self._register(
            "v1.issuing_personalization_design.rejected",
            func,
        )
        return func

    def on_v1_issuing_personalization_design_updated(
        self,
        func: "Callable[[V1IssuingPersonalizationDesignUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingPersonalizationDesignUpdatedEvent` (`v1.issuing_personalization_design.updated`) event notification.
        """
        self._register(
            "v1.issuing_personalization_design.updated",
            func,
        )
        return func

    def on_v1_issuing_token_created(
        self,
        func: "Callable[[V1IssuingTokenCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingTokenCreatedEvent` (`v1.issuing_token.created`) event notification.
        """
        self._register(
            "v1.issuing_token.created",
            func,
        )
        return func

    def on_v1_issuing_token_updated(
        self,
        func: "Callable[[V1IssuingTokenUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingTokenUpdatedEvent` (`v1.issuing_token.updated`) event notification.
        """
        self._register(
            "v1.issuing_token.updated",
            func,
        )
        return func

    def on_v1_issuing_transaction_created(
        self,
        func: "Callable[[V1IssuingTransactionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingTransactionCreatedEvent` (`v1.issuing_transaction.created`) event notification.
        """
        self._register(
            "v1.issuing_transaction.created",
            func,
        )
        return func

    def on_v1_issuing_transaction_purchase_details_receipt_updated(
        self,
        func: "Callable[[V1IssuingTransactionPurchaseDetailsReceiptUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingTransactionPurchaseDetailsReceiptUpdatedEvent` (`v1.issuing_transaction.purchase_details_receipt_updated`) event notification.
        """
        self._register(
            "v1.issuing_transaction.purchase_details_receipt_updated",
            func,
        )
        return func

    def on_v1_issuing_transaction_updated(
        self,
        func: "Callable[[V1IssuingTransactionUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1IssuingTransactionUpdatedEvent` (`v1.issuing_transaction.updated`) event notification.
        """
        self._register(
            "v1.issuing_transaction.updated",
            func,
        )
        return func

    def on_v1_mandate_updated(
        self,
        func: "Callable[[V1MandateUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1MandateUpdatedEvent` (`v1.mandate.updated`) event notification.
        """
        self._register(
            "v1.mandate.updated",
            func,
        )
        return func

    def on_v1_payment_intent_amount_capturable_updated(
        self,
        func: "Callable[[V1PaymentIntentAmountCapturableUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentAmountCapturableUpdatedEvent` (`v1.payment_intent.amount_capturable_updated`) event notification.
        """
        self._register(
            "v1.payment_intent.amount_capturable_updated",
            func,
        )
        return func

    def on_v1_payment_intent_canceled(
        self,
        func: "Callable[[V1PaymentIntentCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentCanceledEvent` (`v1.payment_intent.canceled`) event notification.
        """
        self._register(
            "v1.payment_intent.canceled",
            func,
        )
        return func

    def on_v1_payment_intent_created(
        self,
        func: "Callable[[V1PaymentIntentCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentCreatedEvent` (`v1.payment_intent.created`) event notification.
        """
        self._register(
            "v1.payment_intent.created",
            func,
        )
        return func

    def on_v1_payment_intent_partially_funded(
        self,
        func: "Callable[[V1PaymentIntentPartiallyFundedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentPartiallyFundedEvent` (`v1.payment_intent.partially_funded`) event notification.
        """
        self._register(
            "v1.payment_intent.partially_funded",
            func,
        )
        return func

    def on_v1_payment_intent_payment_failed(
        self,
        func: "Callable[[V1PaymentIntentPaymentFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentPaymentFailedEvent` (`v1.payment_intent.payment_failed`) event notification.
        """
        self._register(
            "v1.payment_intent.payment_failed",
            func,
        )
        return func

    def on_v1_payment_intent_processing(
        self,
        func: "Callable[[V1PaymentIntentProcessingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentProcessingEvent` (`v1.payment_intent.processing`) event notification.
        """
        self._register(
            "v1.payment_intent.processing",
            func,
        )
        return func

    def on_v1_payment_intent_requires_action(
        self,
        func: "Callable[[V1PaymentIntentRequiresActionEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentRequiresActionEvent` (`v1.payment_intent.requires_action`) event notification.
        """
        self._register(
            "v1.payment_intent.requires_action",
            func,
        )
        return func

    def on_v1_payment_intent_succeeded(
        self,
        func: "Callable[[V1PaymentIntentSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentIntentSucceededEvent` (`v1.payment_intent.succeeded`) event notification.
        """
        self._register(
            "v1.payment_intent.succeeded",
            func,
        )
        return func

    def on_v1_payment_link_created(
        self,
        func: "Callable[[V1PaymentLinkCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentLinkCreatedEvent` (`v1.payment_link.created`) event notification.
        """
        self._register(
            "v1.payment_link.created",
            func,
        )
        return func

    def on_v1_payment_link_updated(
        self,
        func: "Callable[[V1PaymentLinkUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentLinkUpdatedEvent` (`v1.payment_link.updated`) event notification.
        """
        self._register(
            "v1.payment_link.updated",
            func,
        )
        return func

    def on_v1_payment_method_attached(
        self,
        func: "Callable[[V1PaymentMethodAttachedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentMethodAttachedEvent` (`v1.payment_method.attached`) event notification.
        """
        self._register(
            "v1.payment_method.attached",
            func,
        )
        return func

    def on_v1_payment_method_automatically_updated(
        self,
        func: "Callable[[V1PaymentMethodAutomaticallyUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentMethodAutomaticallyUpdatedEvent` (`v1.payment_method.automatically_updated`) event notification.
        """
        self._register(
            "v1.payment_method.automatically_updated",
            func,
        )
        return func

    def on_v1_payment_method_detached(
        self,
        func: "Callable[[V1PaymentMethodDetachedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentMethodDetachedEvent` (`v1.payment_method.detached`) event notification.
        """
        self._register(
            "v1.payment_method.detached",
            func,
        )
        return func

    def on_v1_payment_method_updated(
        self,
        func: "Callable[[V1PaymentMethodUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PaymentMethodUpdatedEvent` (`v1.payment_method.updated`) event notification.
        """
        self._register(
            "v1.payment_method.updated",
            func,
        )
        return func

    def on_v1_payout_canceled(
        self,
        func: "Callable[[V1PayoutCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PayoutCanceledEvent` (`v1.payout.canceled`) event notification.
        """
        self._register(
            "v1.payout.canceled",
            func,
        )
        return func

    def on_v1_payout_created(
        self,
        func: "Callable[[V1PayoutCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PayoutCreatedEvent` (`v1.payout.created`) event notification.
        """
        self._register(
            "v1.payout.created",
            func,
        )
        return func

    def on_v1_payout_failed(
        self,
        func: "Callable[[V1PayoutFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PayoutFailedEvent` (`v1.payout.failed`) event notification.
        """
        self._register(
            "v1.payout.failed",
            func,
        )
        return func

    def on_v1_payout_paid(
        self,
        func: "Callable[[V1PayoutPaidEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PayoutPaidEvent` (`v1.payout.paid`) event notification.
        """
        self._register(
            "v1.payout.paid",
            func,
        )
        return func

    def on_v1_payout_reconciliation_completed(
        self,
        func: "Callable[[V1PayoutReconciliationCompletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PayoutReconciliationCompletedEvent` (`v1.payout.reconciliation_completed`) event notification.
        """
        self._register(
            "v1.payout.reconciliation_completed",
            func,
        )
        return func

    def on_v1_payout_updated(
        self,
        func: "Callable[[V1PayoutUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PayoutUpdatedEvent` (`v1.payout.updated`) event notification.
        """
        self._register(
            "v1.payout.updated",
            func,
        )
        return func

    def on_v1_person_created(
        self,
        func: "Callable[[V1PersonCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PersonCreatedEvent` (`v1.person.created`) event notification.
        """
        self._register(
            "v1.person.created",
            func,
        )
        return func

    def on_v1_person_deleted(
        self,
        func: "Callable[[V1PersonDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PersonDeletedEvent` (`v1.person.deleted`) event notification.
        """
        self._register(
            "v1.person.deleted",
            func,
        )
        return func

    def on_v1_person_updated(
        self,
        func: "Callable[[V1PersonUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PersonUpdatedEvent` (`v1.person.updated`) event notification.
        """
        self._register(
            "v1.person.updated",
            func,
        )
        return func

    def on_v1_plan_created(
        self,
        func: "Callable[[V1PlanCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PlanCreatedEvent` (`v1.plan.created`) event notification.
        """
        self._register(
            "v1.plan.created",
            func,
        )
        return func

    def on_v1_plan_deleted(
        self,
        func: "Callable[[V1PlanDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PlanDeletedEvent` (`v1.plan.deleted`) event notification.
        """
        self._register(
            "v1.plan.deleted",
            func,
        )
        return func

    def on_v1_plan_updated(
        self,
        func: "Callable[[V1PlanUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PlanUpdatedEvent` (`v1.plan.updated`) event notification.
        """
        self._register(
            "v1.plan.updated",
            func,
        )
        return func

    def on_v1_price_activated(
        self,
        func: "Callable[[V1PriceActivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceActivatedEvent` (`v1.price.activated`) event notification.
        """
        self._register(
            "v1.price.activated",
            func,
        )
        return func

    def on_v1_price_created(
        self,
        func: "Callable[[V1PriceCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceCreatedEvent` (`v1.price.created`) event notification.
        """
        self._register(
            "v1.price.created",
            func,
        )
        return func

    def on_v1_price_deactivated(
        self,
        func: "Callable[[V1PriceDeactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceDeactivatedEvent` (`v1.price.deactivated`) event notification.
        """
        self._register(
            "v1.price.deactivated",
            func,
        )
        return func

    def on_v1_price_deleted(
        self,
        func: "Callable[[V1PriceDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceDeletedEvent` (`v1.price.deleted`) event notification.
        """
        self._register(
            "v1.price.deleted",
            func,
        )
        return func

    def on_v1_price_lookup_key_changed(
        self,
        func: "Callable[[V1PriceLookupKeyChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceLookupKeyChangedEvent` (`v1.price.lookup_key_changed`) event notification.
        """
        self._register(
            "v1.price.lookup_key_changed",
            func,
        )
        return func

    def on_v1_price_tax_behavior_changed(
        self,
        func: "Callable[[V1PriceTaxBehaviorChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceTaxBehaviorChangedEvent` (`v1.price.tax_behavior_changed`) event notification.
        """
        self._register(
            "v1.price.tax_behavior_changed",
            func,
        )
        return func

    def on_v1_price_updated(
        self,
        func: "Callable[[V1PriceUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PriceUpdatedEvent` (`v1.price.updated`) event notification.
        """
        self._register(
            "v1.price.updated",
            func,
        )
        return func

    def on_v1_product_activated(
        self,
        func: "Callable[[V1ProductActivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductActivatedEvent` (`v1.product.activated`) event notification.
        """
        self._register(
            "v1.product.activated",
            func,
        )
        return func

    def on_v1_product_created(
        self,
        func: "Callable[[V1ProductCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductCreatedEvent` (`v1.product.created`) event notification.
        """
        self._register(
            "v1.product.created",
            func,
        )
        return func

    def on_v1_product_deactivated(
        self,
        func: "Callable[[V1ProductDeactivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductDeactivatedEvent` (`v1.product.deactivated`) event notification.
        """
        self._register(
            "v1.product.deactivated",
            func,
        )
        return func

    def on_v1_product_default_price_changed(
        self,
        func: "Callable[[V1ProductDefaultPriceChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductDefaultPriceChangedEvent` (`v1.product.default_price_changed`) event notification.
        """
        self._register(
            "v1.product.default_price_changed",
            func,
        )
        return func

    def on_v1_product_deleted(
        self,
        func: "Callable[[V1ProductDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductDeletedEvent` (`v1.product.deleted`) event notification.
        """
        self._register(
            "v1.product.deleted",
            func,
        )
        return func

    def on_v1_product_tax_code_changed(
        self,
        func: "Callable[[V1ProductTaxCodeChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductTaxCodeChangedEvent` (`v1.product.tax_code_changed`) event notification.
        """
        self._register(
            "v1.product.tax_code_changed",
            func,
        )
        return func

    def on_v1_product_updated(
        self,
        func: "Callable[[V1ProductUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ProductUpdatedEvent` (`v1.product.updated`) event notification.
        """
        self._register(
            "v1.product.updated",
            func,
        )
        return func

    def on_v1_promotion_code_created(
        self,
        func: "Callable[[V1PromotionCodeCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PromotionCodeCreatedEvent` (`v1.promotion_code.created`) event notification.
        """
        self._register(
            "v1.promotion_code.created",
            func,
        )
        return func

    def on_v1_promotion_code_fully_redeemed(
        self,
        func: "Callable[[V1PromotionCodeFullyRedeemedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PromotionCodeFullyRedeemedEvent` (`v1.promotion_code.fully_redeemed`) event notification.
        """
        self._register(
            "v1.promotion_code.fully_redeemed",
            func,
        )
        return func

    def on_v1_promotion_code_updated(
        self,
        func: "Callable[[V1PromotionCodeUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1PromotionCodeUpdatedEvent` (`v1.promotion_code.updated`) event notification.
        """
        self._register(
            "v1.promotion_code.updated",
            func,
        )
        return func

    def on_v1_quote_accepted(
        self,
        func: "Callable[[V1QuoteAcceptedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1QuoteAcceptedEvent` (`v1.quote.accepted`) event notification.
        """
        self._register(
            "v1.quote.accepted",
            func,
        )
        return func

    def on_v1_quote_canceled(
        self,
        func: "Callable[[V1QuoteCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1QuoteCanceledEvent` (`v1.quote.canceled`) event notification.
        """
        self._register(
            "v1.quote.canceled",
            func,
        )
        return func

    def on_v1_quote_created(
        self,
        func: "Callable[[V1QuoteCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1QuoteCreatedEvent` (`v1.quote.created`) event notification.
        """
        self._register(
            "v1.quote.created",
            func,
        )
        return func

    def on_v1_quote_finalized(
        self,
        func: "Callable[[V1QuoteFinalizedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1QuoteFinalizedEvent` (`v1.quote.finalized`) event notification.
        """
        self._register(
            "v1.quote.finalized",
            func,
        )
        return func

    def on_v1_radar_early_fraud_warning_created(
        self,
        func: "Callable[[V1RadarEarlyFraudWarningCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1RadarEarlyFraudWarningCreatedEvent` (`v1.radar.early_fraud_warning.created`) event notification.
        """
        self._register(
            "v1.radar.early_fraud_warning.created",
            func,
        )
        return func

    def on_v1_radar_early_fraud_warning_updated(
        self,
        func: "Callable[[V1RadarEarlyFraudWarningUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1RadarEarlyFraudWarningUpdatedEvent` (`v1.radar.early_fraud_warning.updated`) event notification.
        """
        self._register(
            "v1.radar.early_fraud_warning.updated",
            func,
        )
        return func

    def on_v1_refund_created(
        self,
        func: "Callable[[V1RefundCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1RefundCreatedEvent` (`v1.refund.created`) event notification.
        """
        self._register(
            "v1.refund.created",
            func,
        )
        return func

    def on_v1_refund_failed(
        self,
        func: "Callable[[V1RefundFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1RefundFailedEvent` (`v1.refund.failed`) event notification.
        """
        self._register(
            "v1.refund.failed",
            func,
        )
        return func

    def on_v1_refund_updated(
        self,
        func: "Callable[[V1RefundUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1RefundUpdatedEvent` (`v1.refund.updated`) event notification.
        """
        self._register(
            "v1.refund.updated",
            func,
        )
        return func

    def on_v1_review_closed(
        self,
        func: "Callable[[V1ReviewClosedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ReviewClosedEvent` (`v1.review.closed`) event notification.
        """
        self._register(
            "v1.review.closed",
            func,
        )
        return func

    def on_v1_review_opened(
        self,
        func: "Callable[[V1ReviewOpenedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1ReviewOpenedEvent` (`v1.review.opened`) event notification.
        """
        self._register(
            "v1.review.opened",
            func,
        )
        return func

    def on_v1_setup_intent_canceled(
        self,
        func: "Callable[[V1SetupIntentCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SetupIntentCanceledEvent` (`v1.setup_intent.canceled`) event notification.
        """
        self._register(
            "v1.setup_intent.canceled",
            func,
        )
        return func

    def on_v1_setup_intent_created(
        self,
        func: "Callable[[V1SetupIntentCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SetupIntentCreatedEvent` (`v1.setup_intent.created`) event notification.
        """
        self._register(
            "v1.setup_intent.created",
            func,
        )
        return func

    def on_v1_setup_intent_requires_action(
        self,
        func: "Callable[[V1SetupIntentRequiresActionEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SetupIntentRequiresActionEvent` (`v1.setup_intent.requires_action`) event notification.
        """
        self._register(
            "v1.setup_intent.requires_action",
            func,
        )
        return func

    def on_v1_setup_intent_setup_failed(
        self,
        func: "Callable[[V1SetupIntentSetupFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SetupIntentSetupFailedEvent` (`v1.setup_intent.setup_failed`) event notification.
        """
        self._register(
            "v1.setup_intent.setup_failed",
            func,
        )
        return func

    def on_v1_setup_intent_succeeded(
        self,
        func: "Callable[[V1SetupIntentSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SetupIntentSucceededEvent` (`v1.setup_intent.succeeded`) event notification.
        """
        self._register(
            "v1.setup_intent.succeeded",
            func,
        )
        return func

    def on_v1_sigma_scheduled_query_run_created(
        self,
        func: "Callable[[V1SigmaScheduledQueryRunCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SigmaScheduledQueryRunCreatedEvent` (`v1.sigma.scheduled_query_run.created`) event notification.
        """
        self._register(
            "v1.sigma.scheduled_query_run.created",
            func,
        )
        return func

    def on_v1_source_canceled(
        self,
        func: "Callable[[V1SourceCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SourceCanceledEvent` (`v1.source.canceled`) event notification.
        """
        self._register(
            "v1.source.canceled",
            func,
        )
        return func

    def on_v1_source_chargeable(
        self,
        func: "Callable[[V1SourceChargeableEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SourceChargeableEvent` (`v1.source.chargeable`) event notification.
        """
        self._register(
            "v1.source.chargeable",
            func,
        )
        return func

    def on_v1_source_failed(
        self,
        func: "Callable[[V1SourceFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SourceFailedEvent` (`v1.source.failed`) event notification.
        """
        self._register(
            "v1.source.failed",
            func,
        )
        return func

    def on_v1_source_refund_attributes_required(
        self,
        func: "Callable[[V1SourceRefundAttributesRequiredEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SourceRefundAttributesRequiredEvent` (`v1.source.refund_attributes_required`) event notification.
        """
        self._register(
            "v1.source.refund_attributes_required",
            func,
        )
        return func

    def on_v1_subscription_schedule_aborted(
        self,
        func: "Callable[[V1SubscriptionScheduleAbortedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleAbortedEvent` (`v1.subscription_schedule.aborted`) event notification.
        """
        self._register(
            "v1.subscription_schedule.aborted",
            func,
        )
        return func

    def on_v1_subscription_schedule_canceled(
        self,
        func: "Callable[[V1SubscriptionScheduleCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleCanceledEvent` (`v1.subscription_schedule.canceled`) event notification.
        """
        self._register(
            "v1.subscription_schedule.canceled",
            func,
        )
        return func

    def on_v1_subscription_schedule_completed(
        self,
        func: "Callable[[V1SubscriptionScheduleCompletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleCompletedEvent` (`v1.subscription_schedule.completed`) event notification.
        """
        self._register(
            "v1.subscription_schedule.completed",
            func,
        )
        return func

    def on_v1_subscription_schedule_created(
        self,
        func: "Callable[[V1SubscriptionScheduleCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleCreatedEvent` (`v1.subscription_schedule.created`) event notification.
        """
        self._register(
            "v1.subscription_schedule.created",
            func,
        )
        return func

    def on_v1_subscription_schedule_expiring(
        self,
        func: "Callable[[V1SubscriptionScheduleExpiringEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleExpiringEvent` (`v1.subscription_schedule.expiring`) event notification.
        """
        self._register(
            "v1.subscription_schedule.expiring",
            func,
        )
        return func

    def on_v1_subscription_schedule_phase_added(
        self,
        func: "Callable[[V1SubscriptionSchedulePhaseAddedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionSchedulePhaseAddedEvent` (`v1.subscription_schedule.phase_added`) event notification.
        """
        self._register(
            "v1.subscription_schedule.phase_added",
            func,
        )
        return func

    def on_v1_subscription_schedule_phase_default_tax_rates_changed(
        self,
        func: "Callable[[V1SubscriptionSchedulePhaseDefaultTaxRatesChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionSchedulePhaseDefaultTaxRatesChangedEvent` (`v1.subscription_schedule.phase_default_tax_rates_changed`) event notification.
        """
        self._register(
            "v1.subscription_schedule.phase_default_tax_rates_changed",
            func,
        )
        return func

    def on_v1_subscription_schedule_phase_end_date_changed(
        self,
        func: "Callable[[V1SubscriptionSchedulePhaseEndDateChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionSchedulePhaseEndDateChangedEvent` (`v1.subscription_schedule.phase_end_date_changed`) event notification.
        """
        self._register(
            "v1.subscription_schedule.phase_end_date_changed",
            func,
        )
        return func

    def on_v1_subscription_schedule_phase_removed(
        self,
        func: "Callable[[V1SubscriptionSchedulePhaseRemovedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionSchedulePhaseRemovedEvent` (`v1.subscription_schedule.phase_removed`) event notification.
        """
        self._register(
            "v1.subscription_schedule.phase_removed",
            func,
        )
        return func

    def on_v1_subscription_schedule_phase_trial_end_changed(
        self,
        func: "Callable[[V1SubscriptionSchedulePhaseTrialEndChangedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionSchedulePhaseTrialEndChangedEvent` (`v1.subscription_schedule.phase_trial_end_changed`) event notification.
        """
        self._register(
            "v1.subscription_schedule.phase_trial_end_changed",
            func,
        )
        return func

    def on_v1_subscription_schedule_released(
        self,
        func: "Callable[[V1SubscriptionScheduleReleasedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleReleasedEvent` (`v1.subscription_schedule.released`) event notification.
        """
        self._register(
            "v1.subscription_schedule.released",
            func,
        )
        return func

    def on_v1_subscription_schedule_updated(
        self,
        func: "Callable[[V1SubscriptionScheduleUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1SubscriptionScheduleUpdatedEvent` (`v1.subscription_schedule.updated`) event notification.
        """
        self._register(
            "v1.subscription_schedule.updated",
            func,
        )
        return func

    def on_v1_tax_rate_created(
        self,
        func: "Callable[[V1TaxRateCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TaxRateCreatedEvent` (`v1.tax_rate.created`) event notification.
        """
        self._register(
            "v1.tax_rate.created",
            func,
        )
        return func

    def on_v1_tax_rate_updated(
        self,
        func: "Callable[[V1TaxRateUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TaxRateUpdatedEvent` (`v1.tax_rate.updated`) event notification.
        """
        self._register(
            "v1.tax_rate.updated",
            func,
        )
        return func

    def on_v1_tax_settings_updated(
        self,
        func: "Callable[[V1TaxSettingsUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TaxSettingsUpdatedEvent` (`v1.tax.settings.updated`) event notification.
        """
        self._register(
            "v1.tax.settings.updated",
            func,
        )
        return func

    def on_v1_terminal_reader_action_failed(
        self,
        func: "Callable[[V1TerminalReaderActionFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TerminalReaderActionFailedEvent` (`v1.terminal.reader.action_failed`) event notification.
        """
        self._register(
            "v1.terminal.reader.action_failed",
            func,
        )
        return func

    def on_v1_terminal_reader_action_succeeded(
        self,
        func: "Callable[[V1TerminalReaderActionSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TerminalReaderActionSucceededEvent` (`v1.terminal.reader.action_succeeded`) event notification.
        """
        self._register(
            "v1.terminal.reader.action_succeeded",
            func,
        )
        return func

    def on_v1_terminal_reader_action_updated(
        self,
        func: "Callable[[V1TerminalReaderActionUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TerminalReaderActionUpdatedEvent` (`v1.terminal.reader.action_updated`) event notification.
        """
        self._register(
            "v1.terminal.reader.action_updated",
            func,
        )
        return func

    def on_v1_test_helpers_test_clock_advancing(
        self,
        func: "Callable[[V1TestHelpersTestClockAdvancingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TestHelpersTestClockAdvancingEvent` (`v1.test_helpers.test_clock.advancing`) event notification.
        """
        self._register(
            "v1.test_helpers.test_clock.advancing",
            func,
        )
        return func

    def on_v1_test_helpers_test_clock_created(
        self,
        func: "Callable[[V1TestHelpersTestClockCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TestHelpersTestClockCreatedEvent` (`v1.test_helpers.test_clock.created`) event notification.
        """
        self._register(
            "v1.test_helpers.test_clock.created",
            func,
        )
        return func

    def on_v1_test_helpers_test_clock_deleted(
        self,
        func: "Callable[[V1TestHelpersTestClockDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TestHelpersTestClockDeletedEvent` (`v1.test_helpers.test_clock.deleted`) event notification.
        """
        self._register(
            "v1.test_helpers.test_clock.deleted",
            func,
        )
        return func

    def on_v1_test_helpers_test_clock_internal_failure(
        self,
        func: "Callable[[V1TestHelpersTestClockInternalFailureEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TestHelpersTestClockInternalFailureEvent` (`v1.test_helpers.test_clock.internal_failure`) event notification.
        """
        self._register(
            "v1.test_helpers.test_clock.internal_failure",
            func,
        )
        return func

    def on_v1_test_helpers_test_clock_ready(
        self,
        func: "Callable[[V1TestHelpersTestClockReadyEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TestHelpersTestClockReadyEvent` (`v1.test_helpers.test_clock.ready`) event notification.
        """
        self._register(
            "v1.test_helpers.test_clock.ready",
            func,
        )
        return func

    def on_v1_topup_canceled(
        self,
        func: "Callable[[V1TopupCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TopupCanceledEvent` (`v1.topup.canceled`) event notification.
        """
        self._register(
            "v1.topup.canceled",
            func,
        )
        return func

    def on_v1_topup_created(
        self,
        func: "Callable[[V1TopupCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TopupCreatedEvent` (`v1.topup.created`) event notification.
        """
        self._register(
            "v1.topup.created",
            func,
        )
        return func

    def on_v1_topup_failed(
        self,
        func: "Callable[[V1TopupFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TopupFailedEvent` (`v1.topup.failed`) event notification.
        """
        self._register(
            "v1.topup.failed",
            func,
        )
        return func

    def on_v1_topup_reversed(
        self,
        func: "Callable[[V1TopupReversedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TopupReversedEvent` (`v1.topup.reversed`) event notification.
        """
        self._register(
            "v1.topup.reversed",
            func,
        )
        return func

    def on_v1_topup_succeeded(
        self,
        func: "Callable[[V1TopupSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TopupSucceededEvent` (`v1.topup.succeeded`) event notification.
        """
        self._register(
            "v1.topup.succeeded",
            func,
        )
        return func

    def on_v1_transfer_created(
        self,
        func: "Callable[[V1TransferCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TransferCreatedEvent` (`v1.transfer.created`) event notification.
        """
        self._register(
            "v1.transfer.created",
            func,
        )
        return func

    def on_v1_transfer_reversed(
        self,
        func: "Callable[[V1TransferReversedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TransferReversedEvent` (`v1.transfer.reversed`) event notification.
        """
        self._register(
            "v1.transfer.reversed",
            func,
        )
        return func

    def on_v1_transfer_updated(
        self,
        func: "Callable[[V1TransferUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V1TransferUpdatedEvent` (`v1.transfer.updated`) event notification.
        """
        self._register(
            "v1.transfer.updated",
            func,
        )
        return func

    def on_v2_commerce_product_catalog_imports_failed(
        self,
        func: "Callable[[V2CommerceProductCatalogImportsFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CommerceProductCatalogImportsFailedEvent` (`v2.commerce.product_catalog.imports.failed`) event notification.
        """
        self._register(
            "v2.commerce.product_catalog.imports.failed",
            func,
        )
        return func

    def on_v2_commerce_product_catalog_imports_processing(
        self,
        func: "Callable[[V2CommerceProductCatalogImportsProcessingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CommerceProductCatalogImportsProcessingEvent` (`v2.commerce.product_catalog.imports.processing`) event notification.
        """
        self._register(
            "v2.commerce.product_catalog.imports.processing",
            func,
        )
        return func

    def on_v2_commerce_product_catalog_imports_succeeded(
        self,
        func: "Callable[[V2CommerceProductCatalogImportsSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CommerceProductCatalogImportsSucceededEvent` (`v2.commerce.product_catalog.imports.succeeded`) event notification.
        """
        self._register(
            "v2.commerce.product_catalog.imports.succeeded",
            func,
        )
        return func

    def on_v2_commerce_product_catalog_imports_succeeded_with_errors(
        self,
        func: "Callable[[V2CommerceProductCatalogImportsSucceededWithErrorsEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CommerceProductCatalogImportsSucceededWithErrorsEvent` (`v2.commerce.product_catalog.imports.succeeded_with_errors`) event notification.
        """
        self._register(
            "v2.commerce.product_catalog.imports.succeeded_with_errors",
            func,
        )
        return func

    def on_v2_core_account_closed(
        self,
        func: "Callable[[V2CoreAccountClosedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountClosedEvent` (`v2.core.account.closed`) event notification.
        """
        self._register(
            "v2.core.account.closed",
            func,
        )
        return func

    def on_v2_core_account_created(
        self,
        func: "Callable[[V2CoreAccountCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountCreatedEvent` (`v2.core.account.created`) event notification.
        """
        self._register(
            "v2.core.account.created",
            func,
        )
        return func

    def on_v2_core_account_including_configuration_customer_capability_status_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingConfigurationCustomerCapabilityStatusUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingConfigurationCustomerCapabilityStatusUpdatedEvent` (`v2.core.account[configuration.customer].capability_status_updated`) event notification.
        """
        self._register(
            "v2.core.account[configuration.customer].capability_status_updated",
            func,
        )
        return func

    def on_v2_core_account_including_configuration_customer_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingConfigurationCustomerUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingConfigurationCustomerUpdatedEvent` (`v2.core.account[configuration.customer].updated`) event notification.
        """
        self._register(
            "v2.core.account[configuration.customer].updated",
            func,
        )
        return func

    def on_v2_core_account_including_configuration_merchant_capability_status_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingConfigurationMerchantCapabilityStatusUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingConfigurationMerchantCapabilityStatusUpdatedEvent` (`v2.core.account[configuration.merchant].capability_status_updated`) event notification.
        """
        self._register(
            "v2.core.account[configuration.merchant].capability_status_updated",
            func,
        )
        return func

    def on_v2_core_account_including_configuration_merchant_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingConfigurationMerchantUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingConfigurationMerchantUpdatedEvent` (`v2.core.account[configuration.merchant].updated`) event notification.
        """
        self._register(
            "v2.core.account[configuration.merchant].updated",
            func,
        )
        return func

    def on_v2_core_account_including_configuration_recipient_capability_status_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEvent` (`v2.core.account[configuration.recipient].capability_status_updated`) event notification.
        """
        self._register(
            "v2.core.account[configuration.recipient].capability_status_updated",
            func,
        )
        return func

    def on_v2_core_account_including_configuration_recipient_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingConfigurationRecipientUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingConfigurationRecipientUpdatedEvent` (`v2.core.account[configuration.recipient].updated`) event notification.
        """
        self._register(
            "v2.core.account[configuration.recipient].updated",
            func,
        )
        return func

    def on_v2_core_account_including_defaults_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingDefaultsUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingDefaultsUpdatedEvent` (`v2.core.account[defaults].updated`) event notification.
        """
        self._register(
            "v2.core.account[defaults].updated",
            func,
        )
        return func

    def on_v2_core_account_including_future_requirements_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingFutureRequirementsUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingFutureRequirementsUpdatedEvent` (`v2.core.account[future_requirements].updated`) event notification.
        """
        self._register(
            "v2.core.account[future_requirements].updated",
            func,
        )
        return func

    def on_v2_core_account_including_identity_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingIdentityUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingIdentityUpdatedEvent` (`v2.core.account[identity].updated`) event notification.
        """
        self._register(
            "v2.core.account[identity].updated",
            func,
        )
        return func

    def on_v2_core_account_including_requirements_updated(
        self,
        func: "Callable[[V2CoreAccountIncludingRequirementsUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountIncludingRequirementsUpdatedEvent` (`v2.core.account[requirements].updated`) event notification.
        """
        self._register(
            "v2.core.account[requirements].updated",
            func,
        )
        return func

    def on_v2_core_account_link_returned(
        self,
        func: "Callable[[V2CoreAccountLinkReturnedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountLinkReturnedEvent` (`v2.core.account_link.returned`) event notification.
        """
        self._register(
            "v2.core.account_link.returned",
            func,
        )
        return func

    def on_v2_core_account_person_created(
        self,
        func: "Callable[[V2CoreAccountPersonCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountPersonCreatedEvent` (`v2.core.account_person.created`) event notification.
        """
        self._register(
            "v2.core.account_person.created",
            func,
        )
        return func

    def on_v2_core_account_person_deleted(
        self,
        func: "Callable[[V2CoreAccountPersonDeletedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountPersonDeletedEvent` (`v2.core.account_person.deleted`) event notification.
        """
        self._register(
            "v2.core.account_person.deleted",
            func,
        )
        return func

    def on_v2_core_account_person_updated(
        self,
        func: "Callable[[V2CoreAccountPersonUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountPersonUpdatedEvent` (`v2.core.account_person.updated`) event notification.
        """
        self._register(
            "v2.core.account_person.updated",
            func,
        )
        return func

    def on_v2_core_account_updated(
        self,
        func: "Callable[[V2CoreAccountUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreAccountUpdatedEvent` (`v2.core.account.updated`) event notification.
        """
        self._register(
            "v2.core.account.updated",
            func,
        )
        return func

    def on_v2_core_event_destination_ping(
        self,
        func: "Callable[[V2CoreEventDestinationPingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2CoreEventDestinationPingEvent` (`v2.core.event_destination.ping`) event notification.
        """
        self._register(
            "v2.core.event_destination.ping",
            func,
        )
        return func

    def on_v2_money_management_adjustment_created(
        self,
        func: "Callable[[V2MoneyManagementAdjustmentCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementAdjustmentCreatedEvent` (`v2.money_management.adjustment.created`) event notification.
        """
        self._register(
            "v2.money_management.adjustment.created",
            func,
        )
        return func

    def on_v2_money_management_financial_account_created(
        self,
        func: "Callable[[V2MoneyManagementFinancialAccountCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementFinancialAccountCreatedEvent` (`v2.money_management.financial_account.created`) event notification.
        """
        self._register(
            "v2.money_management.financial_account.created",
            func,
        )
        return func

    def on_v2_money_management_financial_account_updated(
        self,
        func: "Callable[[V2MoneyManagementFinancialAccountUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementFinancialAccountUpdatedEvent` (`v2.money_management.financial_account.updated`) event notification.
        """
        self._register(
            "v2.money_management.financial_account.updated",
            func,
        )
        return func

    def on_v2_money_management_financial_address_activated(
        self,
        func: "Callable[[V2MoneyManagementFinancialAddressActivatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementFinancialAddressActivatedEvent` (`v2.money_management.financial_address.activated`) event notification.
        """
        self._register(
            "v2.money_management.financial_address.activated",
            func,
        )
        return func

    def on_v2_money_management_financial_address_failed(
        self,
        func: "Callable[[V2MoneyManagementFinancialAddressFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementFinancialAddressFailedEvent` (`v2.money_management.financial_address.failed`) event notification.
        """
        self._register(
            "v2.money_management.financial_address.failed",
            func,
        )
        return func

    def on_v2_money_management_inbound_transfer_available(
        self,
        func: "Callable[[V2MoneyManagementInboundTransferAvailableEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementInboundTransferAvailableEvent` (`v2.money_management.inbound_transfer.available`) event notification.
        """
        self._register(
            "v2.money_management.inbound_transfer.available",
            func,
        )
        return func

    def on_v2_money_management_inbound_transfer_bank_debit_failed(
        self,
        func: "Callable[[V2MoneyManagementInboundTransferBankDebitFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementInboundTransferBankDebitFailedEvent` (`v2.money_management.inbound_transfer.bank_debit_failed`) event notification.
        """
        self._register(
            "v2.money_management.inbound_transfer.bank_debit_failed",
            func,
        )
        return func

    def on_v2_money_management_inbound_transfer_bank_debit_processing(
        self,
        func: "Callable[[V2MoneyManagementInboundTransferBankDebitProcessingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementInboundTransferBankDebitProcessingEvent` (`v2.money_management.inbound_transfer.bank_debit_processing`) event notification.
        """
        self._register(
            "v2.money_management.inbound_transfer.bank_debit_processing",
            func,
        )
        return func

    def on_v2_money_management_inbound_transfer_bank_debit_queued(
        self,
        func: "Callable[[V2MoneyManagementInboundTransferBankDebitQueuedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementInboundTransferBankDebitQueuedEvent` (`v2.money_management.inbound_transfer.bank_debit_queued`) event notification.
        """
        self._register(
            "v2.money_management.inbound_transfer.bank_debit_queued",
            func,
        )
        return func

    def on_v2_money_management_inbound_transfer_bank_debit_returned(
        self,
        func: "Callable[[V2MoneyManagementInboundTransferBankDebitReturnedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementInboundTransferBankDebitReturnedEvent` (`v2.money_management.inbound_transfer.bank_debit_returned`) event notification.
        """
        self._register(
            "v2.money_management.inbound_transfer.bank_debit_returned",
            func,
        )
        return func

    def on_v2_money_management_inbound_transfer_bank_debit_succeeded(
        self,
        func: "Callable[[V2MoneyManagementInboundTransferBankDebitSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementInboundTransferBankDebitSucceededEvent` (`v2.money_management.inbound_transfer.bank_debit_succeeded`) event notification.
        """
        self._register(
            "v2.money_management.inbound_transfer.bank_debit_succeeded",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_canceled(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentCanceledEvent` (`v2.money_management.outbound_payment.canceled`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.canceled",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_created(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentCreatedEvent` (`v2.money_management.outbound_payment.created`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.created",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_failed(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentFailedEvent` (`v2.money_management.outbound_payment.failed`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.failed",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_posted(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentPostedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentPostedEvent` (`v2.money_management.outbound_payment.posted`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.posted",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_returned(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentReturnedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentReturnedEvent` (`v2.money_management.outbound_payment.returned`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.returned",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_under_review(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentUnderReviewEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentUnderReviewEvent` (`v2.money_management.outbound_payment.under_review`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.under_review",
            func,
        )
        return func

    def on_v2_money_management_outbound_payment_updated(
        self,
        func: "Callable[[V2MoneyManagementOutboundPaymentUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementOutboundPaymentUpdatedEvent` (`v2.money_management.outbound_payment.updated`) event notification.
        """
        self._register(
            "v2.money_management.outbound_payment.updated",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_canceled(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentCanceledEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentCanceledEvent` (`v2.money_management.payout_intent.canceled`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.canceled",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_created(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentCreatedEvent` (`v2.money_management.payout_intent.created`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.created",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_pending(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentPendingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentPendingEvent` (`v2.money_management.payout_intent.pending`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.pending",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_posted(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentPostedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentPostedEvent` (`v2.money_management.payout_intent.posted`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.posted",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_processing(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentProcessingEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentProcessingEvent` (`v2.money_management.payout_intent.processing`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.processing",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_requires_action(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentRequiresActionEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentRequiresActionEvent` (`v2.money_management.payout_intent.requires_action`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.requires_action",
            func,
        )
        return func

    def on_v2_money_management_payout_intent_updated(
        self,
        func: "Callable[[V2MoneyManagementPayoutIntentUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutIntentUpdatedEvent` (`v2.money_management.payout_intent.updated`) event notification.
        """
        self._register(
            "v2.money_management.payout_intent.updated",
            func,
        )
        return func

    def on_v2_money_management_payout_method_created(
        self,
        func: "Callable[[V2MoneyManagementPayoutMethodCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutMethodCreatedEvent` (`v2.money_management.payout_method.created`) event notification.
        """
        self._register(
            "v2.money_management.payout_method.created",
            func,
        )
        return func

    def on_v2_money_management_payout_method_updated(
        self,
        func: "Callable[[V2MoneyManagementPayoutMethodUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementPayoutMethodUpdatedEvent` (`v2.money_management.payout_method.updated`) event notification.
        """
        self._register(
            "v2.money_management.payout_method.updated",
            func,
        )
        return func

    def on_v2_money_management_received_credit_available(
        self,
        func: "Callable[[V2MoneyManagementReceivedCreditAvailableEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementReceivedCreditAvailableEvent` (`v2.money_management.received_credit.available`) event notification.
        """
        self._register(
            "v2.money_management.received_credit.available",
            func,
        )
        return func

    def on_v2_money_management_received_credit_failed(
        self,
        func: "Callable[[V2MoneyManagementReceivedCreditFailedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementReceivedCreditFailedEvent` (`v2.money_management.received_credit.failed`) event notification.
        """
        self._register(
            "v2.money_management.received_credit.failed",
            func,
        )
        return func

    def on_v2_money_management_received_credit_returned(
        self,
        func: "Callable[[V2MoneyManagementReceivedCreditReturnedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementReceivedCreditReturnedEvent` (`v2.money_management.received_credit.returned`) event notification.
        """
        self._register(
            "v2.money_management.received_credit.returned",
            func,
        )
        return func

    def on_v2_money_management_received_credit_succeeded(
        self,
        func: "Callable[[V2MoneyManagementReceivedCreditSucceededEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementReceivedCreditSucceededEvent` (`v2.money_management.received_credit.succeeded`) event notification.
        """
        self._register(
            "v2.money_management.received_credit.succeeded",
            func,
        )
        return func

    def on_v2_money_management_recipient_verification_created(
        self,
        func: "Callable[[V2MoneyManagementRecipientVerificationCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementRecipientVerificationCreatedEvent` (`v2.money_management.recipient_verification.created`) event notification.
        """
        self._register(
            "v2.money_management.recipient_verification.created",
            func,
        )
        return func

    def on_v2_money_management_recipient_verification_updated(
        self,
        func: "Callable[[V2MoneyManagementRecipientVerificationUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementRecipientVerificationUpdatedEvent` (`v2.money_management.recipient_verification.updated`) event notification.
        """
        self._register(
            "v2.money_management.recipient_verification.updated",
            func,
        )
        return func

    def on_v2_money_management_transaction_created(
        self,
        func: "Callable[[V2MoneyManagementTransactionCreatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementTransactionCreatedEvent` (`v2.money_management.transaction.created`) event notification.
        """
        self._register(
            "v2.money_management.transaction.created",
            func,
        )
        return func

    def on_v2_money_management_transaction_updated(
        self,
        func: "Callable[[V2MoneyManagementTransactionUpdatedEventNotification, StripeClient], CallbackReturn]",
    ):
        """
        Registers a callback for the `V2MoneyManagementTransactionUpdatedEvent` (`v2.money_management.transaction.updated`) event notification.
        """
        self._register(
            "v2.money_management.transaction.updated",
            func,
        )
        return func

    # event-notification-registration-methods: The end of the section generated from our OpenAPI spec


class _SyncEventNotificationHandler(_BaseEventNotificationHandler[None, bool]):
    """
    Adds synchronous dispatch. Shared by the verifying and non-verifying sync
    handlers, which differ only in how they parse the incoming payload.
    """

    def _dispatch(self, event_notif: "EventNotification") -> None:
        client = self._client.with_stripe_context(event_notif.context)

        if self._pre_handle_callback and not self._pre_handle_callback(
            event_notif, client
        ):
            return

        if callback := self._callback_for(event_notif):
            callback(event_notif, client)
        else:
            self.fallback_callback(
                event_notif, client, self._unhandled_details(event_notif)
            )


class _AsyncEventNotificationHandler(
    _BaseEventNotificationHandler[Awaitable[None], Awaitable[bool]]
):
    """
    Adds asynchronous dispatch. Only the callbacks are awaited: verifying a
    signature and parsing the payload are pure CPU work, so they stay
    synchronous even here.
    """

    async def _dispatch_async(self, event_notif: "EventNotification") -> None:
        client = self._client.with_stripe_context(event_notif.context)

        if self._pre_handle_callback and not await self._pre_handle_callback(
            event_notif, client
        ):
            return

        if callback := self._callback_for(event_notif):
            await callback(event_notif, client)
        else:
            await self.fallback_callback(
                event_notif, client, self._unhandled_details(event_notif)
            )


class StripeEventNotificationHandler(_SyncEventNotificationHandler):
    """
    An on-rails experience for handling Stripe event notifications. Define callbacks for individual event types and an instance of this class will be responsible for verifying and routing the event.
    """

    def __init__(
        self,
        client: "StripeClient",
        webhook_secret: Optional[str],
        fallback_callback: FallbackCallback,
    ) -> None:
        """`webhook_secret` is only marked as `Optional` so it plays nicely with the types commonly returned from web frameworks. This raises a `ValueError` if a secret is not provided."""
        super().__init__(client, fallback_callback)
        if not webhook_secret:
            raise ValueError("webhook_secret must be a non-empty string")
        self._webhook_secret = webhook_secret

    def handle(self, webhook_body: WebhookPayload, sig_header: Optional[str]):
        """
        Process an incoming webhook, routing it to the correct registered callback (or your fallback).

        `sig_header` is only marked as `Optional` so it plays nicely with the types commonly returned from web frameworks. This raises a `SignatureVerificationError` if a signature is not provided.
        """
        # set before parsing, so that even a failed parse locks out registration.
        # modification isn't thread-safe, but we expect callbacks to get registered synchronously at startup
        # making a race condition here unlikely
        self._has_handled_events = True

        event_notif = self._client.parse_event_notification(
            webhook_body, sig_header, self._webhook_secret
        )

        self._dispatch(event_notif)

    @staticmethod
    def without_verification(
        client: "StripeClient",
        fallback_callback: FallbackCallback,
    ) -> "StripeEventNotificationHandlerWithoutVerification":
        return StripeEventNotificationHandlerWithoutVerification(
            client, fallback_callback
        )


class StripeEventNotificationHandlerWithoutVerification(
    _SyncEventNotificationHandler
):
    """
    A variant of StripeEventNotificationHandler that parses events without verifying webhook signatures. Intended for pre-authenticated channels like AWS EventBridge, Azure Event Grid, or your own pre-authenticated queuing system.

    Prefer `StripeEventNotificationHandler.without_verification()` or `client.notification_handler_without_verification()` instead of constructing it directly.
    """

    def handle(self, webhook_body: WebhookPayload):
        """
        Process an incoming webhook, routing it to the correct registered callback (or your fallback) without signature verification.
        """
        self._has_handled_events = True

        event_notif = (
            self._client.parse_event_notification_without_verification(
                webhook_body
            )
        )

        self._dispatch(event_notif)


class AsyncStripeEventNotificationHandler(_AsyncEventNotificationHandler):
    """
    The async equivalent of `StripeEventNotificationHandler`, for use from async web frameworks. Register `async def` callbacks and await `.handle_async()`.
    """

    def __init__(
        self,
        client: "StripeClient",
        webhook_secret: Optional[str],
        fallback_callback: AsyncFallbackCallback,
    ) -> None:
        """`webhook_secret` is only marked as `Optional` so it plays nicely with the types commonly returned from web frameworks. This raises a `ValueError` if a secret is not provided."""
        super().__init__(client, fallback_callback)
        if not webhook_secret:
            raise ValueError("webhook_secret must be a non-empty string")
        self._webhook_secret = webhook_secret

    async def handle_async(
        self, webhook_body: WebhookPayload, sig_header: Optional[str]
    ):
        """
        Process an incoming webhook, routing it to the correct registered callback (or your fallback).

        `sig_header` is only marked as `Optional` so it plays nicely with the types commonly returned from web frameworks. This raises a `SignatureVerificationError` if a signature is not provided.
        """
        self._has_handled_events = True

        event_notif = self._client.parse_event_notification(
            webhook_body, sig_header, self._webhook_secret
        )

        await self._dispatch_async(event_notif)

    @staticmethod
    def without_verification(
        client: "StripeClient",
        fallback_callback: AsyncFallbackCallback,
    ) -> "AsyncStripeEventNotificationHandlerWithoutVerification":
        return AsyncStripeEventNotificationHandlerWithoutVerification(
            client, fallback_callback
        )


class AsyncStripeEventNotificationHandlerWithoutVerification(
    _AsyncEventNotificationHandler
):
    """
    A variant of AsyncStripeEventNotificationHandler that parses events without verifying webhook signatures. Intended for pre-authenticated channels like AWS EventBridge, Azure Event Grid, or your own pre-authenticated queuing system.

    Prefer `AsyncStripeEventNotificationHandler.without_verification()` or `client.async_notification_handler_without_verification()` instead of constructing it directly.
    """

    async def handle_async(self, webhook_body: WebhookPayload):
        """
        Process an incoming webhook, routing it to the correct registered callback (or your fallback) without signature verification.
        """
        self._has_handled_events = True

        event_notif = (
            self._client.parse_event_notification_without_verification(
                webhook_body
            )
        )

        await self._dispatch_async(event_notif)
