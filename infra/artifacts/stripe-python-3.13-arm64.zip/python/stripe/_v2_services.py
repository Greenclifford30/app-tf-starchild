# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe._stripe_service import StripeService
from importlib import import_module
from typing_extensions import TYPE_CHECKING

if TYPE_CHECKING:
    from stripe.v2._billing_service import BillingService
    from stripe.v2._commerce_service import CommerceService
    from stripe.v2._core_service import CoreService
    from stripe.v2._money_management_service import MoneyManagementService
    from stripe.v2._test_helper_service import TestHelperService

_subservices = {
    "billing": ["stripe.v2._billing_service", "BillingService"],
    "commerce": ["stripe.v2._commerce_service", "CommerceService"],
    "core": ["stripe.v2._core_service", "CoreService"],
    "money_management": [
        "stripe.v2._money_management_service",
        "MoneyManagementService",
    ],
    "test_helpers": ["stripe.v2._test_helper_service", "TestHelperService"],
}


class V2Services(StripeService):
    billing: "BillingService"
    commerce: "CommerceService"
    core: "CoreService"
    money_management: "MoneyManagementService"
    test_helpers: "TestHelperService"

    def __init__(self, requestor):
        super().__init__(requestor)

    def __getattr__(self, name):
        try:
            import_from, service = _subservices[name]
            service_class = getattr(
                import_module(import_from),
                service,
            )
            setattr(
                self,
                name,
                service_class(self._requestor),
            )
            return getattr(self, name)
        except KeyError:
            raise AttributeError()
